<?php
session_start();
?>
<?php
if(!isset($_SESSION["DA_user"])){
echo("<script>location.href='login.html';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
//  echo("<script>location.href='lock.php';</script>");
}
else{

    include('connection.php'); 
$account_key=$_SESSION["DA_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];
$admin=$fetch_account['admin_account'];

$todayyear=date("Y");
// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_account['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

if(isset($_POST['edit_project_btn'])){
  //$alert='Ok';
  $PID= $_POST['PID'];
  $nproject = $_POST['nproject'];
  $Pdetails = $_POST['Pdetails'];
  $Pdetails=str_replace("'", "\'", $Pdetails);

  if(!isset($alert)){
    //$savequery=$con->query("INSERT INTO girls(fname,lname,age,phone,email,girl_unique,birthdate,about,district,supervisor,join_date) VALUES ('$fName','$otherName','$age','$pnumber','$newemail','$sku','$herday','$about','$location','$account_key','$now')")or die($con->error);
    $changequery=$con->query("UPDATE programs SET details='$Pdetails' WHERE id='$PID' ")or die($con->error);
     
    if ($changequery) {
        $approvo="Project Details Has been Updated on  Program Called: ".$nproject ." !<br> ";
     
           }else{
            $alert='Saving Failed!';
           }
  }

}

}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Duhamic-Adri | Dashboard</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- Ajax reasons-->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

     <!-- Favicons -->
  <link href="../assets/img/logo.png" rel="icon">
  <link href="../assets/img/logo.png" rel="apple-touch-icon">

  </head>
  <body class="skin-blue">
    <div class="wrapper">

    <?php 
$active_page='dashboard';
include'header.php';?>
      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
            <small>Duhamic-Adri</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa fa-money"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">Donations</span>
                  <span class="info-box-number"><?php echo $count_all_donations; ?> Donors |90 <small>%</small></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
           
               
              <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa fa-users"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">Population</span>
                  <span class="info-box-number"><?php echo $count_all_clients; ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            

            <!-- fix for small devices only -->
            <div class="clearfix visible-sm-block"></div>

            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-green"><i class="ion ion-ios-list-outline"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">Projects</span>
                  <span class="info-box-number"><?php echo $count_all_project; ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            <?php if($admin=='1'){ ?>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">Project Managers</span>
                  <span class="info-box-number"><?php echo $count_all_users; ?></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            <?php  } ?>
          </div><!-- /.row -->
          <?php if(isset($_GET['info'])){ ?>
                     <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4>	<i class="icon fa fa-check"></i> Alert!</h4>
                    <?php echo $_GET['info']; ?>
                  </div>
                  <?php } ?>

                  <?php if(isset($alert)){ ?>
                    <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4>	<i class="icon fa fa-check"></i> Alert!</h4>
                    <?php echo $alert; ?>
                    </div>
                      <?php } ?>
                      <?php if(isset($info)){ ?>
                        <div class="alert alert-info alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4>	<i class="icon fa fa-check"></i> Info!</h4><?php echo $info; ?>
              </div>
                      <?php } ?>

    <?php if(isset($approvo)){ ?>
      <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4>	<i class="icon fa fa-check"></i> Success!</h4> <?php echo $approvo; ?>
                  </div>
                      <?php } ?>


          <?php if($admin==1){?>
          <div class="row">
            <div class="col-md-12">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Admin View And Control</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="row">
                     <!-- Left col -->
            <div class="col-md-8">
              <!-- TABLE: LATEST DonationS -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Latest Donations</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="table-responsive">
                    <table class="table no-margin">
                      <thead>
                        <tr>
                          <th>Transaction ID</th>
                          <th>Donor</th>
                          <th>Amount For</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php  
                       $count=0;
                        while($fetch_donations=$sel_all_donations->fetch_assoc()){ 
                          $count++;
                          if($count<5){
                        ?>
                        <tr>
                          <td><a href="#?payid=<?php echo $fetch_donations['payid'];?>"><?php echo $fetch_donations['payid'];?></a></td>
                          <td><?php echo $fetch_donations['Donator_names'];?></td>
                          
                          <td><div class="sparkbar" data-color="#00a65a" data-height="20"><?php echo "(".$fetch_donations['amount']." RWF)";
                           if($fetch_donations['donate_for']!=0){
                            $spesfic_project=$fetch_donations['donate_for'];
                            $sel_spesfic_project=$con->query("SELECT*from programs WHERE 	id='$spesfic_project' ")or die($con->error);
                            $fetch_spesfic_project=$sel_spesfic_project->fetch_assoc();
                            echo " <b>For</b> ".$fetch_spesfic_project['P_tittle'];
                            }?></div></td>
                            <td><span class="label label-success">Receved</span></td>
                        </tr>
                        <?php }  if($count_all_donations==0){ ?>
                       
                        
                        <tr>
                          <td colspan="4"><span class="label label-info">Donors List will appear Here</span></td>
                       
                        </tr>
                        <?php } }?>
                      </tbody>
                    </table>
                  </div><!-- /.table-responsive -->
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  <!-- <a href="javascript::;" class="btn btn-sm btn-info btn-flat pull-left">Place New Donation</a> -->
                  <a href="reports.php" class="btn btn-sm btn-default btn-flat pull-right">View All Donations</a>
                </div><!-- /.box-footer -->
              </div><!-- /.box -->
            </div><!-- /.col -->


                    <div class="col-md-4">
              <!-- Info Boxes Style 2 -->
              <div class="info-box bg-yellow">
                <span class="info-box-icon"> 
                  <a data-toggle="modal" data-target="#adduser" title="ADD a District">
                    
                  
                  <span class="info-box-icon"><span class="glyphicon glyphicon-user"></span></span>
                  </a></span>
                <div class="info-box-content">
                  <span class="info-box-text">Users/Project Manager(s)</span>
                  <span class="info-box-number"><?php echo $count_all_users; ?></span>
                  <div class="progress">
                    <div class="progress-bar" style="width: 50%"></div>
                  </div>
                  <span class="progress-description">
                    50% Increase in 30 Days
                  </span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
              <div class="example-modal modal fade" id="adduser" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-primary">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">ADD A New user(Project Manager)</h4>
                  </div>
                  <div class="modal-body">
                          <!--New User Form -->
              <form class="row g-3 needs-validation" name="user_form" id="user_form" action="" method="POST" >

                <div class="col-md-6">
                  <label for="validationCustom01" class="form-label">First name</label>
                  <input type="text" class="form-control" id="fname" name="fname"  placeholder="your First name..." required>
                </div>
                <div class="col-md-6">
                  <label for="validationCustom02" class="form-label">Last name</label>
                  <input type="text" class="form-control" id="lname" name="lname" placeholder="your Last name..."  required>
                </div>
                <div class="col-md-6">
                  <label for="validationCustomUsername" class="form-label">Username</label>
                    <input type="text" class="form-control" id="UniqueName" placeholder="duhamic user name..." aria-describedby="inputGroupPrepend" name="UniqueName" required>
                        </div>
                  <div class="col-md-6">
                  <label for="validationCustom05" class="form-label">Gender</label>
                  <fieldset class="row">
                  <div class="col-sm-10">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="gender" id="gridRadios1" value="user" checked>
                      <label class="form-check-label" for="gridRadios1">
                      Male
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="gender" id="gridRadios2" value="Female">
                      <label class="form-check-label" for="gridRadios2">
                      Female
                      </label>
                    </div>
                  </div>
                </fieldset>
                </div>
                <div class="col-md-12">
                  <label for="validationCustomUsername" class="form-label">User ID/email</label>
                    <input type="email" class="form-control" id="UserId" placeholder="email..." aria-describedby="inputGroupPrepend" Name="UserId" required>
                     </div>
                <div class="col-md-6">
                  <label for="validationCustom04" class="form-label">Location</label>
                  <select class="form-control" id="validationCustom04" name="ulocation" required>
                    <option selected  value="">Choose Location...</option>
                    <?php
                  $sel_locations=$con->query("SELECT*from locations ")or die($con->error);
                  while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                <option value="<?php echo $fetch_locations['id'] ?>" ><?php echo $fetch_locations['District'] ?></option>
                    <?php }  ?>
                    </select>
                
                </div>
                <div class="col-md-6">
                  <label for="validationCustom05" class="form-label">Account-Type</label>
                  <fieldset class="row mb-3">
                  
                  <div class="col-sm-10">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="Rtype" id="gridRadios1" value="user" checked>
                      <label class="form-check-label" for="gridRadios1">
                      User
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="Rtype" id="gridRadios2" value="Manager">
                      <label class="form-check-label" for="gridRadios2">
                      Admin
                      </label>
                    </div>
                  </div>
                </fieldset>
                
                </div>
                <div class="col-md-12">
                  
                  <div class="input-group has-validation">
                    <span class="input-group-text" id="inputGroupPrepend">Default U.Password</span>
                    <input type="text" class="form-control" id="validationCustomUsername" value="Duhamic@123" aria-describedby="inputGroupPrepend" Name="Dpass" required>
                    <div class="invalid-feedback">
                      Please Decide a User Password.
                    </div>
                  </div>
                  </div>

                  <div class="col-md-12">
                  <label for="validationCustom04" class="form-label">Assign the User to the Project</label>
                  <select class="form-control" id="validationCustom04" name="Project" required>
                    <option selected  value="">Choose Project...</option>
                    <?php
                  $sel_programs=$con->query("SELECT*from programs ")or die($con->error);
                  while($fetch_programs=$sel_programs->fetch_assoc()){ ?>
                <option value="<?php echo $fetch_programs['id'] ?>" ><?php echo $fetch_programs['P_tittle'] ?></option>
                    <?php }  ?>
                               
                  </select>
                
                </div>

                <div class="col-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                    <label class="form-check-label" for="invalidCheck">
                      Agree to terms and conditions
                    </label>
                    
                  </div>
                </div>
               <div id="usermsg" class="pull-center" >Message</div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" name="saveUser" id="saveUser" class="btn btn-outline" >Save changes</button>
                                     

                  </form>
                  </div>
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
          </div><!-- /.example-modal -->
              <div class="info-box bg-green">
                <a data-toggle="modal" data-target="#addlocation" title="ADD a District">
                  <span class="info-box-icon"><span class="glyphicon glyphicon-pushpin" tittle="ADD a District"></span></span></a>
                <div class="info-box-content">
                  <span class="info-box-text">Locations/Districts</span>
                  <span class="info-box-number"><?php echo $count_destinations; ?></span>
                  <div class="progress">
                    <div class="progress-bar" style="width: 20%"></div>
                  </div>
                  <span class="progress-description">
                    We focus on wher we need to Develop
                  </span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
              
           <div class="example-modal modal fade" id="addlocation" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-success">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Current Locations</h4>
                  </div>
                  <div class="modal-body">
                  <ol>
                    <?php
                  while($fetch_locations= $sel_destinations->fetch_assoc()){ ?>
                         <li><?php echo $fetch_locations['District'] ?></li>
                                <?php }  ?>
                  
                        </ol>
                    <p>Use Below inputs to Add more District&hellip;</p>
                    <form name="locations_form" class="form-goup" id="locations_form" method="post">
                    <div class="row">
                    <div class="col-lg-6">
                        <input type="text" name="locprovince" id="locprovince" placeholder="State/Province" class="form-control" required="">
                     </div><!-- /.col-lg-6 -->
                    <div class="col-lg-6">
                        <input type="text" name="newdistrict" id="newdistrict" placeholder="District" class="form-control" required="">
                      </div><!-- /.col-lg-6 -->
                  </div><!-- /.row -->
                  <div id="locationmsg" class="pull-center" >Message</div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" name="location_submit" id="location_submit" class="btn btn-outline" >Save changes</button>
                    <script>
                                                        $(document).ready(function(){
                                                        
                                                            $('#locations_form').on('submit', function(event){
                                                          event.preventDefault();
                                                          if($('#locprovince').val() != '' && $('#newdistrict').val() != '')
                                                          {
                                                           var form_data = $(this).serialize();
                                                           $.ajax({
                                                            url:"admin_process.php",
                                                            method:"POST",
                                                            data:form_data,
                                                            success:function(data)
                                                            {
                                                             //$('#assign_form')[0].reset();
                                                             $('#locationmsg').html(data);
                                                            }
                                                           })
                                                          }
                                                          else
                                                          {
                                                           alert("Both Fields are Required");
                                                          }
                                                         });

                                                            $('#user_form').on('submit', function(event){
                                                          event.preventDefault();
                                                          if($('#fname').val() != '' && $('#lname').val() != '')
                                                          {
                                                           var form_data = $(this).serialize();
                                                           $.ajax({
                                                            url:"admin_process.php",
                                                            method:"POST",
                                                            beforeSend:function(){
                                                              $('#loadinguser').removeClass("hidden");
                                                              $('#submit_user_btn').prop("disabled",true);
                                                              
                                                            },
                                                            data:form_data,
                                                            success:function(data)
                                                            {
                                                             //$('#assign_form')[0].reset();
                                                             $('#usermsg').html(data);
                                                             $('#loadinguser').addClass("hidden");
                                                             $('#submit_user_btn').prop("disabled",false);
                                                            }
                                                           })
                                                          }
                                                          else
                                                          {
                                                           alert("Both Fields are Required");
                                                          }
                                                         });
                                                         $('#project_form').on('submit', function(event){
                                                          event.preventDefault();
                                                          if($('#Pname').val() != '' && $('#ulocation').val() != '')
                                                          {
                                                           var form_data = $(this).serialize();
                                                           $.ajax({
                                                            url:"admin_process.php",
                                                            method:"POST",
                                                            beforeSend:function(){
                                                              $('#loadinglabel').removeClass("hidden");
                                                              $('#submit_project_btn').prop("disabled",true);
                                                              
                                                            },
                                                            data:form_data,
                                                            success:function(data)
                                                            {
                                                             //$('#project_form')[0].reset();
                                                             $('#projectmsg').html(data);
                                                             $('#loadinglabel').addClass("hidden");
                                                             $('#submit_project_btn').prop("disabled",false);
                                                            }
                                                           })
                                                          }
                                                          else
                                                          {
                                                           alert("Both Fields are Required");
                                                          }
                                                         });
                                                        });
                                                        </script>

                  </form>
                  </div>
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
          </div><!-- /.Location-modal -->
          
              <div class="info-box bg-aqua">
                
                <a data-toggle="modal" data-target="#addproject" title="ADD A PROJECT">
                    
                  
                    <span class="info-box-icon"><span class="info-box-icon"><i class="ion-ios-chatbubble-outline"></i></span></span>
                    </a></span>
                <div class="info-box-content">
                  <span class="info-box-text">Projects</span>
                  <span class="info-box-number"><?php echo $count_all_project; ?></span>
                  <div class="progress">
                    <div class="progress-bar" style="width: 40%"></div>
                  </div>
                  <span class="progress-description">
                    I Manage <?php echo $count_all_project; ?> Project(s)
                  </span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->

            <div class="example-modal modal fade" id="addproject" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-default">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Initiating a Project..</h4>
                  </div>
                  <form role="form" id="project_form" name="add_project">
                  <div class="modal-body">
                   
                   
                        <div class="box-body">
                        <label for="Pname" class="form-label">Title or name of the program</label>
                        <input class="form-control input-lg" type="text" name="Pname" id="Pname" placeholder="Project name/Tittle&hellip;" required="">
                        
                       
                            <div class="col-md-6">
                              <label for="validationCustom04" class="form-label">Location</label>
                              <select class="form-control" id="validationCustom04" name="ulocation" required>
                                <option selected  value="">Choose Location...</option>
                                <?php
                              $sel_locations=$con->query("SELECT*from locations ")or die($con->error);
                              while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                            <option value="<?php echo $fetch_locations['id'] ?>" ><?php echo $fetch_locations['District']; ?></option>
                                <?php }  ?>
                              </select>
                            </div>  

                          <div class="col-md-6">
                            <label for="validationCustom04" class="form-label">Responsible Manager</label>
                            <select class="form-control" id="validationCustom04" name="pmanager" required>
                              <option selected  value="">Choose a User...</option>
                            
                            <?php
                            $sel_manager=$con->query("SELECT*from users ")or die($con->error);
                            while($fetch_manager=$sel_manager->fetch_assoc()){ ?>
                            <option value="<?php echo $fetch_manager['id'] ?>" ><?php echo $fetch_manager['user_name']; ?></option>
                              <?php }  ?>
                            </select>
                        
                          </div>

                         
                        </div><!-- /.box-body -->
                        <div id="projectmsg" class="pull-center" ><br/><br/><br/></div>
                        <label class="btn-primary btn-sm btn-block hidden" id="loadinglabel">Loading...</label>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" id="submit_project_btn">Save changes</button>
                  </div>
                  </form>
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
          </div><!-- /.example-modal -->
          
                  </div><!-- /.row -->
                </div><!-- ./box-body -->
                
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!--/.row -->
           <?php } ?>
          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <div class="col-md-8">
              <!-- TABLE: LATEST DonationS -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Current of People Registered in Projects That I Manage</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>Names</th>
                        <th>ID Number</th>
                        <th>Application Date</th>
                        <th>Program Tittle</th>
                        <th>Location</th>
                        <th>Status</th>
                       
                      </tr>
                    </thead>
                    <tbody>
                     <?php  
                     $sel_applicants=$con->query("SELECT*from applicants where program_manager='$account_key' ORDER BY id DESC")or die($con->error);
                     $count_applicants=$sel_applicants->num_rows;
                     if($count_applicants>0){
                        while($fetch_applicants=$sel_applicants->fetch_assoc()){
                            $person=$fetch_applicants['applicant_id'];
                            $hischoise=$fetch_applicants['program_id'];

                            $sel_applicantnow=$con->query("SELECT*from citizens where id='$person'")or die($con->error);
                            $fetch_applicantnow=$sel_applicantnow->fetch_assoc();

                            $sel_programnow=$con->query("SELECT*from programs where id='$hischoise'")or die($con->error);
                            $fetch_programnow=$sel_programnow->fetch_assoc();

                            if($fetch_applicants['status']=='Approved'){
                                $color='success';
                            }elseif($fetch_applicants['status']=='Pending'){
                                $color='warning';
                            }elseif($fetch_applicants['status']=='Denied'){
                                $color='danger';
                            }elseif($fetch_applicants['status']=='Received'){
                                $color='info';
                            }else{
                                $color='Primary';
                            }

                            ?>

                   
                      <tr>
                        <td><?php echo $fetch_applicantnow['fname']." ".$fetch_applicantnow['lname'];?></td>
                        <td><?php echo $fetch_applicantnow['program_id'];?></td>
                        <td><?php echo $fetch_applicants['regist_date'];?></td>
                        <td><?php echo $fetch_programnow['P_tittle'];?></td>
                        <td><?php echo $fetch_applicantnow['district_name'];?></td>
                        <td><span class="label label-<?php echo $color;?>"><?php echo $fetch_applicants['status']; ?></span></td>
                     
                      </tr>
        
                        
                      <?php    }
                     }
                     ?>
                 
                    </tbody>
                    <tfoot>
                      <tr>
                      <th>Names</th>
                        <th>ID Number</th>
                        <th>Application Date</th>
                        <th>Program Tittle</th>
                        <th>Location</th>
                        <th>Status</th>
                        
                      </tr>
                    </tfoot>
                  </table>
                  </div><!-- /.table-responsive -->
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  <a  data-toggle="modal" data-target="#myModal" class="btn btn-sm btn-info btn-flat pull-left">Recrut More People</a>
                  <a href="applicants.php" class="btn btn-sm btn-default btn-flat pull-right">View All Citizens</a>
                </div><!-- /.box-footer -->
              </div><!-- /.box -->
            </div><!-- /.col -->

            <div class="col-md-4">
              <!-- PRODUCT LIST -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Projects I Manage</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <!-- <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <ul class="products-list product-list-in-box">
                    <?php 
                        
                        if($count_my_project>0){
                        while($fetch_my_project=$sel_my_project->fetch_assoc()){
                          $currentproject=$fetch_my_project['id'];
                          $currentlocation=$fetch_my_project['location'];
                          
                          $result = mysqli_query($con, 'SELECT SUM(amount) AS Totalamount FROM donations where donate_for="$currentproject"'); 
                          $row = mysqli_fetch_assoc($result); 
                          $sum = $row['Totalamount'];
                        ?>
                    <li class="item">
                      <div class="product-img">
                      <a data-toggle="modal" data-target="#myproject<?php echo $currentproject; ?>" title="View PROJECT">
                      <button class="btn btn-box-tool" data-toggle="tooltip" title="Edit Requirements/Terms&Conditions"><i class="fa fa-edit"></i></button>
                        </a>
                    </div>
                    <div class="example-modal modal fade" id="myproject<?php echo $currentproject; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-default">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><strong><?php echo $fetch_my_project['P_tittle'];?></strong></h4>
                  </div>
                  <form role="form" id="edit_project_form" name="Edit_project" method="POST">
                  <div class="modal-body">
                   
                   
                        <div class="box-body">
                       
                       
                            <div class="col-md-6">
                              <label for="validationCustom04" class="form-label">Location Of the Project</label>
                              
                                <?php
                              $sel_locations=$con->query("SELECT*from locations where id='$currentlocation' ")or die($con->error);
                             $fetch_locations=$sel_locations->fetch_assoc();
                                 ?>
                                <input class="form-control input-lg" type="text" name="Pname" readonly="" value="<?php echo $fetch_locations['District']; ?>" id="Pname" placeholder="Project name/Tittle&hellip;" required="">
                                <input class="form-control input-lg" type="hidden" name="PID" readonly="" value="<?php echo $fetch_my_project['id'];?>" required="">
                                <input class="form-control input-lg" type="hidden" name="nproject" readonly="" value="<?php echo $fetch_my_project['P_tittle'];?>" id="Pname" placeholder="Project name/Tittle&hellip;" required="">

                            </div> 
                            <div class="col-md-12">
                            <label for="Pname" class="form-label">Program Details/Requirements</label>
                        <textarea class="form-control input-lg" type="text" name="Pdetails" id="Pdetails" placeholder="Project Details/Requirements &hellip;" required=""><?php echo $fetch_my_project['details'];?></textarea>
                        
                        </div> 
                          

                         
                        </div><!-- /.box-body -->
                        <div id="projectmsg" class="pull-center" ><br/><br/><br/></div>
                        <label class="btn-primary btn-sm btn-block hidden" id="loadinglabel">Loading...</label>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="edit_project_btn" id="edit_project_btn">Save changes</button>
                  </div>
                  </form>
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
          </div><!-- /.example-modal -->
                      <div class="product-info">
                        <a data-toggle="modal" data-target="#myproject<?php echo $currentproject; ?>" class="product-title"><?php echo $fetch_my_project['P_tittle'];?><span class="label label-success pull-right"><?php echo $sum; ?></span></a>
                        <span class="product-description">
                        <?php echo $fetch_locations['District']; ?>
                        </span>
                      </div>
                    </li><!-- /.item -->
                    <?php } }else{ ?>
                    <li class="item">
                      
                      <div class="product-info">
                        <a href="javascript::;" class="product-title">Project You Manage Will appear Here! <span class="label label-danger pull-right">0 For now</span></a>
                        
                      </div>
                    </li><!-- /.item -->
                    <?php } ?>
                   
                  </ul>
                </div><!-- /.box-body -->
                
              </div><!-- /.box -->
            </div><!-- /.col -->
         
          
 
            <div class='col-md-4'>
              <div class="box box-default">
              <div class="" >
                        <div class="alert alert-info text-center">
                          <h3> CREATE A CITIZEN</h3> 
                          <hr />
                            <i class="fa fa-warning fa-4x"></i>
                          <p>
                         This is for creating the citizen to be used in this Prototype.
                         Since I was not able to be handed the Public Database
                        </p>
                          <hr />
                          <div class="panel-body">
                            <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                              Register a new Citizen
                            </button>
                            
                        </div>
                        
                        </div>
                        
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">New Citizen Identifications </h4>
                                        </div>
                                        <div class="modal-body">
                                                
                                    <form name="citizen_form" class="form-goup" role="form" id="citizen_form" method="post">
                                
                                                <div class="form-group col-md-6">
                                                    <label>First Name</label>
                                                    <input class="form-control" id="fnamecit" name="fname" placeholder="First Name" type="text" required=""/>
                                                    <p class="help-block">Help text here.</p>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label>Other Name</label>
                                                    <input class="form-control" type="text" id="lnamecit" name="lname"  required=""/>
                                                    <p class="help-block">Help text here.</p>
                                                </div>

                                                <div class="form-group col-md-8">
                                                        <label>Gender</label>
                                                        <div class="radio">
                                                <label>
                                                    <input type="radio" name="gender" id="gender1" value="Male" checked="">Male
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="gender" id="gender2" value="Female">Female
                                                </label>
                                            </div>
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label>Location/District</label>
                                                     
                                                        <select class="form-control" name="location" id="location" aria-label="District" required="" />
                                                              <option selected>Select District</option>
                                                              <?php
                                                                $sel_locations=$con->query("SELECT*from locations ")or die($con->error);
                                                                while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                                                              <option value="<?php echo $fetch_locations['id'] ?>" ><?php echo $fetch_locations['District'] ?></option>
                                                                  <?php }  ?>
                                                            </select>
                                                        <p class="help-block" id="locationhelp"></p>
                                                    </div>


                                            <div class="form-group col-md-8">
                                                        <label>Enter Email</label>
                                                        <input class="form-control" name="usermail" type="email" required=""/>
                                                <p class="help-block">Help text here.</p>
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label>Phone</label>
                                                        <input class="form-control" name="phone" id="phone" type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "10" required="" />
                                                <p class="help-block">Help text here.</p>
                                                    </div>

                                                    <div class="col-md-2">
                                                        <div class="form-floating">
                                                    <label for="bday" class="col-form-label">BIRTH DATES</label>
                                                        </div>
                                                    </div>


                            <div class="col-md-3">
                              <div class="col-md-12">
                                <div class="form-floating">
                                <label for="floatingDay">Day</label>
                                  <input type="Number" class="form-control" name="bday" max="31" min="1" id="floatingDay" placeholder="Day" required="" />
                                  
                                
                                </div>
                              </div>
                            </div>
                          
                            <div class="col-md-3">
                              <div class="form-floating">
                            
                              <label for="floatingbMonth">Month</label>
                                <select class="form-control" id="bMonth" name="bMonth" aria-label="Month" required="" />
                                  <option value="1">Jan</option>
                                  <option value="2">Feb</option>
                                  <option value="3">Marc</option>
                                  <option value="4">Apr</option>
                                  <option value="5">May</option>
                                  <option value="6">Jun</option>
                                  <option value="7">Jul</option>
                                  <option value="8">Aug</option>
                                  <option value="9">Sept</option>
                                  <option value="10">Oct</option>
                                  <option value="11">Nov</option>
                                  <option value="12">Dec</option>

                                </select>
                              
                              </div>
                            </div>

                            <div class="col-md-3">
                              <div class="form-floating mb-3">
                              <label for="floatingSelect">Year</label>
                                <select class="form-control" id="byear" name="byear" aria-label="Year" required="" />
                                  <option selected>Select Year</option>
                                  <?php                       
                                  for($i=$todayyear;$i>=1960;$i--){
                                      echo '<option value="'.$i.'">'.$i.'</option>';
                                  } ?>

                                  <option value="1959">...</option>
                                </select>
                                
                              </div>
                            </div> 
                                                <script>
                                                                    $(document).ready(function(){
                                                                    
                                                                        $('#citizen_form').on('submit', function(event){
                                                                      event.preventDefault();
                                                                      if($('#fnamecit').val() != '' && $('#lnamecit').val() != '')
                                                                      {
                                                                      var form_data = $(this).serialize();
                                                                      $.ajax({
                                                                        url:"new_citizen.php",
                                                                        method:"POST",
                                                                        data:form_data,
                                                                        success:function(data)
                                                                        {
                                                                        //$('#assign_form')[0].reset();
                                                                        $('#msg').html(data);
                                                                        }
                                                                      })
                                                                      }
                                                                      else
                                                                      {
                                                                      alert("Both Fields are Required");
                                                                      }
                                                                    });

                                                                    $('#byear').on('change', function(event){
                                                                      event.preventDefault();
                                                                      if($('#gender').val() != '' && $('#byear').val() != '')
                                                                      {
                                                                      var form_data = $(this).serialize();
                                                                      
                                                                      $.ajax({
                                                                        url:"rondom_id.php",
                                                                        method:"POST",
                                                                        data:form_data,
                                                                        
                                                                        success:function(data)
                                                                        {
                                                                        //$('#assign_form')[0].reset();
                                                                        $('#idfield').html(data);
                                                                        }
                                                                      })
                                                                      }
                                                                      else
                                                                      {
                                                                      alert("Birth dates are Required");
                                                                      }
                                                                    });

                                                                    

                                                                    });

                                                                    </script>


                                                  <div id="idfield" class="row">
                                                  <label class="form-group col-md-12">__</label>
                                                  <hr />
                                                                <div class="form-group col-md-3">
                                                                                <label>National ID</label>
                                                </div> 
                                                <div class="form-group col-md-8">
                                                    <input class="form-control" id="NID" name="NID" type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "16" required="" />
                                                    <p class="help-block" id="idhelp"></p>
                                                </div>
                                                </div>
                                                     <div id="msg"></div>
                                                     
                                        
                            
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <button type="submit" name="citizen_submit" id="citizen_submit" value="1" class="btn btn-primary">Save changes</button>
                                      </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                 </div>
            </div><!-- /.col -->
          </div><!-- /.row -->

      

          

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <footer class="main-footer">
        <div class="pull-right hidden-xs">
         
        </div>
        <strong>Copyright &copy; 2022 <a href="#">DuhamicAdri</a>.</strong> All rights reserved.
      </footer>

    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- Sparkline -->
    <script src="plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- jvectormap -->
    <script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <!-- daterangepicker -->
    <script src="plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- ChartJS 1.0.1 -->
    <script src="plugins/chartjs/Chart.min.js" type="text/javascript"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard2.js" type="text/javascript"></script>

    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
  </body>
</html>