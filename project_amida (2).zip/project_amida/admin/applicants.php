<?php
session_start();
?>
<?php
if(!isset($_SESSION["DA_user"])){
echo("<script>location.href='login.html';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
//  echo("<script>location.href='lock.php';</script>");
}
else{

    include('connection.php'); 
$account_key=$_SESSION["DA_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];
$admin=$fetch_account['admin_account'];

$todayyear=date("Y");
$now=time();
if(isset($_POST['status_submit'])){
    $changes=$_POST['status_submit'];
    $status=$_POST['status'];
    $msg=$_POST['message'];
    $msg=str_replace("'", "\'", $msg);
    
    $sel_req_availables=$con->query("SELECT*from applicants  where id='$changes' ")or die($con->error);
    if($count_req_availables=$sel_req_availables->num_rows>0){
        $query=$con->query("UPDATE applicants SET status='$status',deny_reason='$msg',approvo_date='$now' WHERE id ='$changes' ")or die($con->error);
        echo '<script>alert("Case Has been Updated");</script>';   
    }

}else if(isset($_GET['approve'])){
    $changes=$_GET['approve'];
    $sel_req_availables=$con->query("SELECT*from applicants  where id='$changes' and status!='Approved'")or die($con->error);
    if($count_req_availables=$sel_req_availables->num_rows>0){
        $query=$con->query("UPDATE applicants SET status='Approved',approvo_date='$now' WHERE id ='$changes' ")or die($con->error);
        echo '<script>alert("Request Has been Approved");</script>';   
    }
}
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Duhamic-Adri | Applicants</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- Ajax reasons-->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

    <!-- Favicons -->
  <link href="../assets/img/logo.png" rel="icon">
  <link href="../assets/img/logo.png" rel="apple-touch-icon">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
    <?php 
$active_page='applicants';
include'header.php';?>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Citizens
            <small>Applicants</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            
            <li class="active">Applicants</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box box-warning">
              <div class="box-header" data-toggle="tooltip" title="Filter For My programs">
                <h3 class="box-title">List of People Registered in Projects That I Manage</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-primary btn-xs" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <!-- <button class="btn btn-primary btn-xs" data-widget="remove"><i class="fa fa-times"></i></button> -->
                  </div>
              
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>Names</th>
                        <th>ID Number</th>
                        <th>Application Date</th>
                        <th>Program Tittle</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Settings <i class="fa fa-wrench"></i></th>
                      </tr>
                    </thead>
                    <tbody>
                     <?php  
                     $sel_applicants=$con->query("SELECT*from applicants where program_manager='$account_key' ORDER BY id DESC")or die($con->error);
                     $count_applicants=$sel_applicants->num_rows;
                     if($count_applicants>0){
                        while($fetch_applicants=$sel_applicants->fetch_assoc()){
                            $person=$fetch_applicants['applicant_id'];
                            $hischoise=$fetch_applicants['program_id'];

                            $sel_applicantnow=$con->query("SELECT*from citizens where id='$person'")or die($con->error);
                            $fetch_applicantnow=$sel_applicantnow->fetch_assoc();

                            $sel_programnow=$con->query("SELECT*from programs where id='$hischoise'")or die($con->error);
                            $fetch_programnow=$sel_programnow->fetch_assoc();

                            if($fetch_applicants['status']=='Approved'){
                                $color='success';
                            }elseif($fetch_applicants['status']=='Pending'){
                                $color='warning';
                            }elseif($fetch_applicants['status']=='Denied'){
                                $color='danger';
                            }elseif($fetch_applicants['status']=='Received'){
                                $color='info';
                            }else{
                                $color='Primary';
                            }

                            ?>

                   
                      <tr>
                        <td><?php echo $fetch_applicantnow['fname']." ".$fetch_applicantnow['lname'];?></td>
                        <td><?php echo $fetch_applicantnow['program_id'];?></td>
                        <td><?php echo $fetch_applicants['regist_date'];?></td>
                        <td><?php echo $fetch_programnow['P_tittle'];?></td>
                        <td><?php echo $fetch_applicantnow['district_name'];?></td>
                        <td><span class="label label-<?php echo $color;?>"><?php echo $fetch_applicants['status']; ?></span></td>
                        <td>  <div class="btn-group">
                      <button class="btn btn-block btn-primary  dropdown-toggle" data-toggle="dropdown">Change status<i class="fa fa-wrench"></i></button>
                      <ul class="dropdown-menu" role="menu">
                      <li><a href="applicants.php?approve=<?php echo $fetch_applicants['id']?>"><i class="fa fa-thumbs-up"></i> Approve</a></li>
                        <li><a data-toggle="modal" data-target="#Deny<?php echo $fetch_applicants['id']?>" title="ADD a District"><i class="fa  fa-thumbs-down"></i> Deny For a Reason</a></li>

                       
                        <li class="divider"></li>
                        <li><a href="#" class="btn btn-block btn-social btn-github"> Remove from program <i class="fa  fa-times-circle-o"></i></a></li>
                      </ul>
                    </div></td>
                      </tr>
                       <!-- Modal for Deny -->
                       <div class="example-modal modal fade" id="Deny<?php echo $fetch_applicants['id']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-danger">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Changing Status For <?php echo $fetch_applicantnow['fname']." ".$fetch_applicantnow['lname'];?>'s Case</h4>
                  </div>
                  <div class="modal-body">
                  <ol>
                  
           
                  
                        </ol>
                    <p>Use Below inputs to Add more District&hellip;</p>
                    <form name="locations_form" action="" class="form-goup" id="status_form" method="post">
                    <div class="form-group">
                      <label>Choose a New status</label>
                      <select class="form-control" name="status" required="">
                      <option Value="" selected>Please choose</option>
                        <option value="Pending">Pending</option>
                        <option value="Denied">Denied</option>
                        <option value="Approved">Approved</option>
                      
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Reason / Message /Updates</label>
                      <textarea class="form-control" rows="3" name="message" placeholder="Enter a Message,Reason or Update on A case" required=""></textarea>
                    </div>

                  <div id="statusnmsg" class="pull-center" ></div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" name="status_submit" id="status_submit" value="<?php echo $fetch_applicants['id']?>" class="btn btn-outline" >Save changes</button>
                    

                  </form>
                  </div>
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
          </div><!-- /.Location-modal -->
                        <!-- END OF Deny modal -->
                        
                      <?php    }
                     }
                     ?>
                 
                    </tbody>
                    <tfoot>
                      <tr>
                      <th>Names</th>
                        <th>ID Number</th>
                        <th>Application Date</th>
                        <th>Program Tittle</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Settings <i class="fa fa-wrench"></i></th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>

              <div class="box box-danger" >
                <div class="box-header">
                  <h3 class="box-title">List of Whole citizens (Registered and Non registered)</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example2" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Names</th>
                        <th>Gender</th>
                        <th>District</th>
                        <th>ID Number</th>
                        <th>Telephone</th>
                        <th>Registered By</th>
                        <th>Recruit</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php  
                       
                       while($fetch_citizens=$sel_all_clients->fetch_assoc()){ 
                       ?>
                      <tr>
                        <td><strong><?php echo $fetch_citizens['fname']." ".$fetch_citizens['lname'];?></strong></td>
                        <td><?php echo $fetch_citizens['gender'];?> </td>
                        <td><?php  $locid=$fetch_citizens['district'];
                            $sel_locations=$con->query("SELECT*from locations where id='$locid' ")or die($con->error);
                            $fetch_district=$sel_locations->fetch_assoc();
                            echo $fetch_district['District'];
                            ?>
                            </td>
                        <td><?php echo $fetch_citizens['program_id'];?></td>
                        <td><?php echo $fetch_citizens['telephone'];?></td>
                        <td><?php $jointime=$fetch_citizens['join_date'];
                        print date("M d, Y (D)",$jointime); ?></td>
                        <td><div class="btn-group">
                      <button class="btn btn-block btn-primary pull-right dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bookmark"></i> Recruit</button>
                      <ul class="dropdown-menu" role="menu">
                       
                        <li><a href="#"><i class="fa fa-bookmark"></i> Assign to project</a></li>
                        
                        <li class="divider"></li>
                        <li><a href="#" class="btn btn-block btn-social btn-github">Remove from program</a></li>
                      </ul>
                    </div></td>
                      </tr>
                      <?php }  ?>
                      
                      
                    </tbody>
                    <tfoot>
                      <tr>
                      <th>Names</th>
                        <th>Gender</th>
                        <th>District</th>
                        <th>ID Number</th>
                        <th>Telephone</th>
                        <th>Registered By</th>
                        <th>Recruit</th>
                      </tr>
                    </tfoot>
                  </table>
                  <div class="panel-body">
                            <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                              Register a new Citizen
                            </button>
                           
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">New Client Identifications </h4>
                                        </div>
                                        <div class="modal-body">
                                                
                                    <form name="citizen_form" class="form-goup" role="form" id="citizen_form" method="post">
                                
                                                <div class="form-group col-md-6">
                                                    <label>First Name</label>
                                                    <input class="form-control" id="fname" name="fname" placeholder="First Name" type="text" required=""/>
                                                    <p class="help-block">Help text here.</p>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label>Other Name</label>
                                                    <input class="form-control" type="text" id="lname" name="lname"  required=""/>
                                                    <p class="help-block">Help text here.</p>
                                                </div>

                                                <div class="form-group col-md-8">
                                                        <label>Gender</label>
                                                        <div class="radio">
                                                <label>
                                                    <input type="radio" name="gender" id="gender1" value="Male" checked="">Male
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="gender" id="gender2" value="Female">Female
                                                </label>
                                            </div>
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label>Location/District</label>
                                                     
                                                        <select class="form-control" name="location" id="location" aria-label="District" required="">
                                                              <option selected>Select District</option>
                                                              <?php
                                                                $sel_locations=$con->query("SELECT*from locations ")or die($con->error);
                                                                while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                                                              <option value="<?php echo $fetch_locations['id'] ?>" ><?php echo $fetch_locations['District'] ?></option>
                                                                  <?php }  ?>
                                                            </select>
                                                        <p class="help-block" id="locationhelp"></p>
                                                    </div>


                                            <div class="form-group col-md-8">
                                                        <label>Enter Email</label>
                                                        <input class="form-control" name="usermail" type="email" required=""/>
                                                <p class="help-block">Help text here.</p>
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label>Phone</label>
                                                        <input class="form-control" name="phone" id="phone" type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "10" required="" />
                                                <p class="help-block">Help text here.</p>
                                                    </div>

                                                    <div class="col-md-2">
                                                        <div class="form-floating">
                                                    <label for="bday" class="col-form-label">BIRTH DATES</label>
                                                        </div>
                                                    </div>
                            <div class="col-md-3">
                              <div class="col-md-12">
                                <div class="form-floating">
                                <label for="floatingDay">Day</label>
                                  <input type="Number" class="form-control" name="bday" max="31" min="1" id="floatingDay" placeholder="Day" required="" />
                                  
                                
                                </div>
                              </div>
                            </div>
                          
                            <div class="col-md-3">
                              <div class="form-floating">
                            
                              <label for="floatingbMonth">Month</label>
                                <select class="form-control" id="bMonth" name="bMonth" aria-label="Month" required="" />
                                  <option value="1">Jan</option>
                                  <option value="2">Feb</option>
                                  <option value="3">Marc</option>
                                  <option value="4">Apr</option>
                                  <option value="5">May</option>
                                  <option value="6">Jun</option>
                                  <option value="7">Jul</option>
                                  <option value="8">Aug</option>
                                  <option value="9">Sept</option>
                                  <option value="10">Oct</option>
                                  <option value="11">Nov</option>
                                  <option value="12">Dec</option>

                                </select>
                              
                              </div>
                            </div>

                            <div class="col-md-3">
                              <div class="form-floating mb-3">
                              <label for="floatingSelect">Year</label>
                                <select class="form-control" id="byear" name="byear" aria-label="Year" required="" />
                                  <option selected>Select Year</option>
                                  <?php                       
                                  for($i=$todayyear;$i>=1960;$i--){
                                      echo '<option value="'.$i.'">'.$i.'</option>';
                                  } ?>

                                  <option value="1959">...</option>
                                </select>
                                
                              </div>
                            </div> 
                                                <script>
                                                                    $(document).ready(function(){
                                                                    
                                                                        $('#citizen_form').on('submit', function(event){
                                                                      event.preventDefault();
                                                                      if($('#gender').val() != '' && $('#fname').val() != '')
                                                                      {
                                                                      var form_data = $(this).serialize();
                                                                      $.ajax({
                                                                        url:"new_citizen.php",
                                                                        method:"POST",
                                                                        beforeSend:function(){
                                                                        $('#loadingcitizen').removeClass("hidden");
                                                                        $('#citizen_submit').prop("disabled",true);
                                                                        
                                                                        },
                                                                        data:form_data,
                                                                        success:function(data)
                                                                        {
                                                                        //$('#assign_form')[0].reset();
                                                                        $('#msg').html(data);
                                                                        $('#loadingcitizen').addClass("hidden");
                                                                        $('#citizen_submit').prop("disabled",false);
                                                                        }
                                                                      })
                                                                      }
                                                                      else
                                                                      {
                                                                      alert("Both Fields are Required");
                                                                      }
                                                                    });

                                                                    $('#byear').on('change', function(event){
                                                                      event.preventDefault();
                                                                      if($('#gender').val() != '' && $('#byear').val() != '')
                                                                      {
                                                                      var form_data = $(this).serialize();
                                                                      
                                                                      $.ajax({
                                                                        url:"rondom_id.php",
                                                                        method:"POST",
                                                                       
                                                                        data:form_data,
                                                                                                                                              
                                                                        success:function(data)
                                                                        {
                                                                        //$('#assign_form')[0].reset();
                                                                        $('#idfield').html(data);
                                                                       
                                                                        }
                                                                      })
                                                                      }
                                                                      else
                                                                      {
                                                                      alert("Birth dates are Required");
                                                                      }
                                                                    });

                                                                    });

                                                                    </script>


                                                  <div id="idfield" class="row">
                                                  <label class="form-group col-md-12">__</label>
                                                  <hr />
                                                                <div class="form-group col-md-3">
                                                                 <label>National ID</label>
                                                </div> 
                                                <div class="form-group col-md-8">
                                                    <input class="form-control" id="NID" name="NID" type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "16" required="" />
                                                    <p class="help-block" id="idhelp"></p>
                                                </div>
                                                </div>
                                                     <div id="msg"></div>
                                        
                                             <label class="btn-primary btn-sm btn-block hidden" id="loadingcitizen">Loading...</label>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <button type="submit" name="citizen_submit" id="citizen_submit" value="1" class="btn btn-primary">Save changes</button>
                                      </form>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                        </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
         
        </div>
        <strong>Copyright &copy; 2022 <a href="#">DuhamicAdri</a>.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- DATA TABES SCRIPT -->
    <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- page script -->
    <script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
    </script>

  </body>
</html>
