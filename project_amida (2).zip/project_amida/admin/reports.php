<?php
session_start();
?>
<?php
if(!isset($_SESSION["DA_user"])){
echo("<script>location.href='login.html';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
//  echo("<script>location.href='lock.php';</script>");
}
else{

    include('connection.php'); 
$account_key=$_SESSION["DA_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];
$admin=$fetch_account['admin_account'];

$todayyear=date("Y");
// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_account['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Duhamic-Adri | Users</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
    <?php 
$active_page='report';
include'header.php';?>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Reports
            <small>Donations, Project, ...</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Users</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            
        <div class="col-md-8">
              <!-- TABLE: LATEST DonationS -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title"> Donations</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <!-- <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="table-responsive">
                    <table class="table no-margin">
                      <thead>
                        <tr>
                          <th>Transaction ID</th>
                          <th>Donor</th>
                          <th>Amount For</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php  
                       $count=0;
                        while($fetch_donations=$sel_all_donations->fetch_assoc()){ 
                          $count++;
                        ?>
                        <tr>
                          <td><a href="#?payid=<?php echo $fetch_donations['payid'];?>"><?php echo $fetch_donations['payid'];?></a></td>
                          <td><?php echo $fetch_donations['Donator_names'];?></td>
                          
                          <td><div class="sparkbar" data-color="#00a65a" data-height="20"><?php echo "(".$fetch_donations['amount']." RWF)";
                           if($fetch_donations['donate_for']!=0){
                            $spesfic_project=$fetch_donations['donate_for'];
                            $sel_spesfic_project=$con->query("SELECT*from programs WHERE 	id='$spesfic_project' ")or die($con->error);
                            $fetch_spesfic_project=$sel_spesfic_project->fetch_assoc();
                            echo " <b>For</b> ".$fetch_spesfic_project['P_tittle'];
                            }?></div></td>
                            <td><span class="label label-success">Receved</span></td>
                        </tr>
                        <?php }  if($count_all_donations==0){ ?>
                       
                        
                        <tr>
                          <td colspan="4"><span class="label label-info">Donors List will appear Here</span></td>
                       
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div><!-- /.table-responsive -->
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  <a href="javascript::;" class="btn btn-sm btn-info btn-flat pull-left">Place New Donation</a>
                  <a href="javascript::;" class="btn btn-sm btn-default btn-flat pull-right">View All Donations</a>
                </div><!-- /.box-footer -->
              </div><!-- /.box -->
            </div><!-- /.col -->

            <div class="col-md-4">
              <!-- PRODUCT LIST -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Available Projects</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <!-- <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <ul class="products-list product-list-in-box">
                    <?php 
                        
                        if($count_my_project>0){
                        while($fetch_my_project=$sel_all_project->fetch_assoc()){
                          $currentproject=$fetch_my_project['id'];
                          $currentlocation=$fetch_my_project['location'];
                          
                          $result = mysqli_query($con, 'SELECT SUM(amount) AS Totalamount FROM donations where donate_for="$currentproject"'); 
                          $row = mysqli_fetch_assoc($result); 
                          $sum = $row['Totalamount'];
                        ?>
                    <li class="item">
                      <div class="product-img">
                      <button class="btn btn-box-tool" data-toggle="tooltip" title="Edit Requirements/Terms&Conditions"><i class="fa fa-star"></i></button>
                    </div>
                    
                      <div class="product-info">
                        <a  class="product-title"><?php echo $fetch_my_project['P_tittle'];?><span class="label label-success pull-right"><?php echo $sum; ?></span></a>
                        <span class="product-description">
                        <?php
                              $sel_locations=$con->query("SELECT*from locations where id='$currentlocation' ")or die($con->error);
                             $fetch_locations=$sel_locations->fetch_assoc();
                        echo $fetch_locations['District']; ?> 
                        </span>
                      </div>
                    </li><!-- /.item -->
                    <?php } }else{ ?>
                    <li class="item">
                      
                      <div class="product-info">
                        <a href="javascript::;" class="product-title">Available Project Will appear Here! <span class="label label-danger pull-right">0 For now</span></a>
                        
                      </div>
                    </li><!-- /.item -->
                    <?php } ?>
                   
                  </ul>
                </div><!-- /.box-body -->
                
              </div><!-- /.box -->
            </div><!-- /.col -->
                 

          <div class="row">
          <div class="col-md-8">
              <!-- TABLE: LATEST DonationS -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Current of People Registered in Projects That I Manage</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>Names</th>
                        <th>ID Number</th>
                        <th>Application Date</th>
                        <th>Program Tittle</th>
                        <th>Location</th>
                        <th>Status</th>
                       
                      </tr>
                    </thead>
                    <tbody>
                     <?php  
                     $sel_applicants=$con->query("SELECT*from applicants where program_manager='$account_key' ORDER BY id DESC")or die($con->error);
                     $count_applicants=$sel_applicants->num_rows;
                     if($count_applicants>0){
                        while($fetch_applicants=$sel_applicants->fetch_assoc()){
                            $person=$fetch_applicants['applicant_id'];
                            $hischoise=$fetch_applicants['program_id'];

                            $sel_applicantnow=$con->query("SELECT*from citizens where id='$person'")or die($con->error);
                            $fetch_applicantnow=$sel_applicantnow->fetch_assoc();

                            $sel_programnow=$con->query("SELECT*from programs where id='$hischoise'")or die($con->error);
                            $fetch_programnow=$sel_programnow->fetch_assoc();

                            if($fetch_applicants['status']=='Approved'){
                                $color='success';
                            }elseif($fetch_applicants['status']=='Pending'){
                                $color='warning';
                            }elseif($fetch_applicants['status']=='Denied'){
                                $color='danger';
                            }elseif($fetch_applicants['status']=='Received'){
                                $color='info';
                            }else{
                                $color='Primary';
                            }

                            ?>

                   
                      <tr>
                        <td><?php echo $fetch_applicantnow['fname']." ".$fetch_applicantnow['lname'];?></td>
                        <td><?php echo $fetch_applicantnow['program_id'];?></td>
                        <td><?php echo $fetch_applicants['regist_date'];?></td>
                        <td><?php echo $fetch_programnow['P_tittle'];?></td>
                        <td><?php echo $fetch_applicantnow['district_name'];?></td>
                        <td><span class="label label-<?php echo $color;?>"><?php echo $fetch_applicants['status']; ?></span></td>
                     
                      </tr>
        
                        
                      <?php    }
                     }
                     ?>
                 
                    </tbody>
                    <tfoot>
                      <tr>
                      <th>Names</th>
                        <th>ID Number</th>
                        <th>Application Date</th>
                        <th>Program Tittle</th>
                        <th>Location</th>
                        <th>Status</th>
                        
                      </tr>
                    </tfoot>
                  </table>
                  </div><!-- /.table-responsive -->
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                  <a  data-toggle="modal" data-target="#myModal" class="btn btn-sm btn-info btn-flat pull-left">Recrut More People</a>
                  <a href="applicants.php" class="btn btn-sm btn-default btn-flat pull-right">View All Citizens</a>
                </div><!-- /.box-footer -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      < <footer class="main-footer">
        <div class="pull-right hidden-xs">
         
        </div>
        <strong>Copyright &copy; 2022 <a href="#">DuhamicAdri</a>.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
  </body>
</html>
