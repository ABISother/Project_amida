<header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
         <img src="assets/img/logo.png" alt="">
        <!-- <h1>DA</h1> -->
      </a>

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>
          <li><a href="#about">About</a></li>
           <li><a href="#faq">Projects</a></li>
         <!-- <li><a href="pricing.html">Pricing</a></li> -->
          <!-- <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
          </li> -->
          <!-- <li><a href="contact.html">Contact</a></li> -->
          <li><a class="get-a-quote" href="donate.php">Donate</a></li>
        </ul>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <?php 

include('connection.php');
$sel_all_users=$con->query("SELECT*from users")or die($con->error);
   $count_all_users=$sel_all_users->num_rows;

   //  $sel_about=$con->query("SELECT*from company")or die($con->error);
   // $count_about=$sel_about->num_rows;

    $sel_destinations=$con->query("SELECT*from locations")or die($con->error);
    $count_destinations=$sel_destinations->num_rows;

     $sel_all_clients=$con->query("SELECT*from citizens ORDER BY id DESC;")or die($con->error);
    $count_all_clients=$sel_all_clients->num_rows;

    $sel_all_applicants=$con->query("SELECT*from applicants ORDER BY id DESC")or die($con->error);
    $count_all_applicants=$sel_all_applicants->num_rows;

   $sel_all_donations=$con->query("SELECT*from donations ORDER BY id DESC")or die($con->error);
    $count_all_donations=$sel_all_donations->num_rows;

    $sel_all_project=$con->query("SELECT*from programs ")or die($con->error);
    $count_all_project=$sel_all_project->num_rows;



   ?>