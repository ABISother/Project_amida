<?php
//donate.php
if(isset($_POST['amount'])){

    include('connection.php'); 
     
        $donations = $_POST['amount'];
        $mName = $_POST['dnames'];
        $mName=str_replace("'", "\'", $mName);
        $email = $_POST['email'];
        $email=str_replace("'", "\'", $email);
        $message = $_POST['message'];
        $message=str_replace("'", "\'", $message);
        $project = $_POST['project'];
        $project=str_replace("'", "\'", $project);

        $phone= $_POST['phone'];

        $now=time();

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $alert = "Invalid email format Try Again";
            ?>
            <script> 
            var errormsg="Invalid email format Try Again";
     $('#error-message').addClass("d-block");
     $('#error-message').html(errormsg);
     $('#email').addClass("is-invalid");
    $('#donationloader').removeClass('d-block')
              </script> 
          <?PHP
        
          }
     //===========generate the sku=============
function checkkeys($con,$randstr){
	$sql ="SELECT * FROM donations";
	$result=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_assoc($result)){
		if($row['payid']==$randstr){
			$keyExists=true;
			break;
			}else{
			$keyExists=false;
		}
    return $keyExists;
	}
}
function generatekey($con){
	$keylength = 4;
$str="1234567890";
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
while ($checkkeys==true) {
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
}
return $randstr;
}
 //echo generatekey($con);
$sku=generatekey($con);
//------------======------End of sku Generations----========----
$payid='DA'.$sku;
        
   
   if(!isset($alert)){
     //$savequery=$con->query("INSERT INTO girls(email,lname,age,phone,email,girl_unique,birthdate,about,district,supervisor,join_date) VALUES ('$email','$otherName','$age','$pnumber','$newemail','$sku','$herday','$about','$location','$account_key','$now')")or die($con->error);
     $saveactivity=$con->query("INSERT INTO donations(payid,date_of_trans,Donator_names,Donor_email,donor_phone,amount,donate_for,comments) VALUES ('$payid','$now','$mName','$email','$phone','$donations','$project','$message')")or die($con->error);
 
     if ($saveactivity) {
        //  $approvo="The photo was successfully assigned to ".$her_email." is added in System Please complete all related info!<br> ";
       echo "Your Donations has been sent. Thank you!";
         ?>
         <script> 
         var msg="Thanks For Donating";
         $('#msg').addClass("d-block");
           </script> 
       <?PHP
            }else{
                echo "Error";
            } 
   }
       
      }else{

        echo "YOU DIDN'T SPECIFY YOUR DONATIONS!";
      }
   
   

?>