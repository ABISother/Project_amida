<?php
  /**
  * Requires the "PHP Email Form" library
  * The "PHP Email Form" library is available only in the pro version of the template
  * The library should be uploaded to: vendor/php-email-form/php-email-form.php
  * For more info and help: https://bootstrapmade.com/php-email-form/
  */

  // Replace abirihosother@gmail.com with your real receiving email address
  $receiving_email_address = 'abirihosother@gmail.com';

  require_once('../connection.php');



  if(isset($_POST['project']))
  {
    $donornames=$_POST['dnames'];
    $project=$_POST['project'];
   
    $phone=$_POST['phone'];
    $dmail=$_POST['email'];
    $amount=$_POST['amount'];
    $message=$_POST['message'];
  
    //===========generate the sku=============
function checkkeys($con,$randstr){
	$sql ="SELECT * FROM donations";
	$result=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_assoc($result)){
		if($row['payid']==$randstr){
			$keyExists=true;
			break;
			}else{
			$keyExists=false;
		}
    return $keyExists;
	}
}
function generatekey($con){
	$keylength = 4;
$str="1234567890";
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
while ($checkkeys==true) {
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
}
return $randstr;
}
 //echo generatekey($con);
$sku=generatekey($con);
$transid="DA".$sku;
//------------======------End of sku Generations----========----
      // $Gbday=$bday."-".$bMonth."-".$byear;
      $now=time();
      // $userday=strtotime($Gbday);
  
      $sel_availables=$con->query("SELECT*from donations where 	donor_phone='$phone' ")or die($con->error);
      if($count_availables=$sel_availables->num_rows>0){
        echo '<label style="color:red;">Contact: '.$phone.' It seems You are not new to this System<br />Welcome back! </label>';
       //$alert="Invalid ID: '.$userid.'Are already used in with different user<br />Please Provide Differnt phone";
      // }
      $new=0;
      
      }else{
        $new=1;
      }
  
      
  
      if(!isset($alert)){
        $savequery=$con->query("INSERT INTO donations(payid,date_of_trans,Donator_names,donor_phone,amount,donate_for,comments,new_donor) VALUES ('$transid','$now','$donornames','$phone','$amount','$project','$message','$new')")or die($con->error);
        if ($savequery) {
            $approvo="New Member is added in System Please complete all related info!<br> ";
            // $_SESSION["new_member"] = $sku;
            echo '<label style="color:green;">Success<br />'.$amount.' rwf Have been received well</label>';
            //$saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,event_time) VALUES ('$account_key','New Name has been Added','info','New name: $fName. has been added to the system','$now')")or die($con->error);
       
                   // $names=$_POST['names'];
      //$content=$_POST['content'];
    
      
    
            // if(isset($_SESSION["new_member"])){
            //   echo("<script>location.href='new_2.php';</script>");
            //  }
            // sleep(7);
            //echo("<script>location.href='citizen.php?newuser=$userid';</script>");
               } 
      }

  // $contact = new PHP_Email_Form;
  // $contact->ajax = true;
  
  // $contact->to = $receiving_email_address;
  // $contact->from_name = $_POST['name'];
  // $contact->from_email = $_POST['email'];
  // $contact->subject = 'Donating a Project';

  // // Uncomment below code if you want to use SMTP to send emails. You need to enter your correct SMTP credentials
  // /*
  // $contact->smtp = array(
  //   'host' => 'example.com',
  //   'username' => 'example',
  //   'password' => 'pass',
  //   'port' => '587'
  // );
  // */

  // $contact->add_message( $_POST['departure'], 'City of Departure');
  // $contact->add_message( $_POST['delivery'], 'Delivery City');
  // $contact->add_message( $_POST['weight'], 'Total Weight (kg)');
  // $contact->add_message( $_POST['dimensions'], 'Dimensions (cm)');
  // $contact->add_message( $_POST['name'], 'Name');
  // $contact->add_message( $_POST['email'], 'Email');
  // $contact->add_message( $_POST['phone'], 'Phone');
  // $contact->add_message( $_POST['message'], 'Message', 10);

  // echo $contact->send();
  }
?>
