<?php
session_start();
?>
<?php
if(!isset($_SESSION["DA_user"])){
echo("<script>location.href='login.html';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
//  echo("<script>location.href='lock.php';</script>");
echo '<label color="red">You are not Authorized</label>';
}
else{

    include('connection.php'); 
$account_key=$_SESSION["DA_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

$todayyear=date("Y");

// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_account['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

}
//citizen.php
require_once('connection.php');



if(isset($_POST['NID']))
{
  $fname=$_POST['fname'];
  $lname=$_POST['lname'];
  $location=$_POST['location'];
  $bday=$_POST['bday'];
  $phone=$_POST['phone'];
  $usermail=$_POST['usermail'];
  $userid=$_POST['NID'];
  $gender=$_POST['gender'];
     $bMonth=$_POST['bMonth'];
    $byear=$_POST['byear'];

    $Gbday=$bday."-".$bMonth."-".$byear;
    $now=time();
    $userday=strtotime($Gbday);

    $sel_availables=$con->query("SELECT*from citizens where telephone='$phone' ")or die($con->error);
    if($count_availables=$sel_availables->num_rows>0){
      echo '<label style="color:red;">Contact: '.$phone.' Are already used in with different user<br />Please Provide Differnt phone </label>';
     $alert="Invalid ID: '.$userid.'Are already used in with different user<br />Please Provide Differnt phone";
    }else{
      $sel_availables=$con->query("SELECT*from citizens where program_id='$userid' ")or die($con->error);
      if($count_availables=$sel_availables->num_rows>0){
        echo '<label style="color:red;">Invalid ID<br />User ID Number Are already used in this System</label>';
       $alert="Contact: '.$userid.'Are already used in with different user<br />Please Provide Differnt phone";
      }
    }


    $sel_destinations=$con->query("SELECT*from locations where id='$location' ")or die($con->error);
    $fetch_destinations=$sel_destinations->fetch_assoc();
    $district_name=$fetch_destinations['District'];
    

    if(!isset($alert)){
      $savequery=$con->query("INSERT INTO citizens(fname,lname,gender,program_id,telephone,email,district,district_name,birthdate,join_date,registered_by) VALUES ('$fname',' $lname','$gender','$userid','$phone','$usermail','$location','$district_name','$userday','$now','$account_key')")or die($con->error);
      if ($savequery) {
          $approvo="New Member is added in System Please complete all related info!<br> ";
          // $_SESSION["new_member"] = $sku;
          echo '<label style="color:green;">Success<br />'.$fname.' is a new member in System</label>';
          //$saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,event_time) VALUES ('$account_key','New Name has been Added','info','New name: $fName. has been added to the system','$now')")or die($con->error);
     
                 // $names=$_POST['names'];
    //$content=$_POST['content'];
    $to =$usermail;
    $subject = 'Successfuly Registered in Duhamic-adri System';
    $message= '<p style="color:#4c5a7d"> Hello '.$fname.' , </p>';
    $message .= '<p>This is to inform that  </p>';
    $message .= '<p>You are now one of Citizens that are Registered in Duhamic Adri Program: </p>';
    $message .= '<p> Names:'.$fname." ".$lname.'</p>';
    $message .= '<p> User ID: '.$userid.'</p>';
    
    if(isset($alert)){
      $message .= '<p> Belows are Some Errors Occured:</p>';
    $message .= '<p> Errors:'.$alert.'</p>';
    }else{
      $message .= '<p> Thank you!</p>';
    }
    $message .= '<p> ------------------------------------------------------------------------------</p>';
    $message .= '<p>  If this was you, you don’t need to do anything. If not, we’ll help you secure your account. call Us now
     <a href="tel:+250786193917"> (+250) 786 193 917 </a> or just Reply to <b>fiacrerukundo8@gmail.com</b>!</p>';
    
    $headers = "From: DUHAMIC-ADRI \r\n";
    $headers .= "Reply-To: fiacrerukundo8@gmail.com\r\n";
    
    $headers .= "Content-type: text/html\r\n";
    
    $send=mail($to, $subject, $message, $headers);
    
    if($send){
      $approvo .="New Member is added in System Please complete all related info!<br> ";
    }else{
      $info="Email sending failed!";
    }
          // if(isset($_SESSION["new_member"])){
          //   echo("<script>location.href='new_2.php';</script>");
          //  }
          // sleep(7);
          echo("<script>location.href='index.php?info=New Citizen has just joined with program id: $userid';</script>");
             } 
    }

   }else{
     echo '<label>Not Setted</label>';
                   } ?>