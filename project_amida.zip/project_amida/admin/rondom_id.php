<?php
session_start();

require_once('connection.php');

 //===========generate the sku=============
 function checkkeys($con,$randstr){
	$sql ="SELECT * FROM citizens";
	$result=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_assoc($result)){
		if($row['program_id']==$randstr){
			$keyExists=true;
			break;
			}else{
			$keyExists=false;
		}
    return $keyExists;
	}
}
function generatekey($con){
	$keylength = 11;
$str="1234567890";
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
while ($checkkeys==true) {
$randstr = substr(str_shuffle($str),0, $keylength);
$checkkeys= checkkeys($con,$randstr);
}
return $randstr;
}
 //echo generatekey($con);
$restid=generatekey($con);
//------------======------End of sku Generations----========----

if(isset($_POST['byear']))
{
    // $gender=$_POST['gender'];
    // $bMonth=$_POST['bMonth'];
    $byear=$_POST['byear'];

$idcard='1'.$byear.$restid;
?>

<label class="form-group col-md-12">__</label>
                       <hr />
                                    <div class="form-group col-md-3">
                                                    <label>National ID</label>
                    </div> 
                                                <div class="form-group col-md-8">
                                                    <input class="form-control" id="NID" value="<?php echo $idcard; ?>" name="NID" type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  maxlength = "16" required="" />
                                                    <p class="help-block" id="idhelp">This is a reserved</p>
                                                </div>
                 <?php } ?>