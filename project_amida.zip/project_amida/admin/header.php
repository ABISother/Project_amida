      
      <?php 

$sel_all_users=$con->query("SELECT*from users")or die($con->error);
   $count_all_users=$sel_all_users->num_rows;

   //  $sel_about=$con->query("SELECT*from company")or die($con->error);
   // $count_about=$sel_about->num_rows;

    $sel_destinations=$con->query("SELECT*from locations")or die($con->error);
    $count_destinations=$sel_destinations->num_rows;

     $sel_all_clients=$con->query("SELECT*from citizens ORDER BY id DESC;")or die($con->error);
    $count_all_clients=$sel_all_clients->num_rows;

    $sel_all_applicants=$con->query("SELECT*from applicants ORDER BY id DESC")or die($con->error);
    $count_all_applicants=$sel_all_applicants->num_rows;

   $sel_all_donations=$con->query("SELECT*from donations ORDER BY id DESC")or die($con->error);
    $count_all_donations=$sel_all_donations->num_rows;

    $sel_all_project=$con->query("SELECT*from programs ")or die($con->error);
    $count_all_project=$sel_all_project->num_rows;

    $sel_my_project=$con->query("SELECT*from programs WHERE 	responsible_user='$account_key' ")or die($con->error);
$count_my_project=$sel_my_project->num_rows;


   ?>
   
   <header class="main-header">
      <!-- Logo -->
      <a href="index.php" class="logo"><b>Duhamic</b>Adri</a>
      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <!-- Messages: style can be found in dropdown.less-->
            <li class="dropdown messages-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-envelope-o"></i>
                <span class="label label-success">4</span>
              </a>
              <ul class="dropdown-menu">
                <li class="header">You have 4 messages</li>
                <li>
                  <!-- inner menu: contains the actual data -->
                  <ul class="menu">
                    <li><!-- start message -->
                      <a href="#">
                        <div class="pull-left">
                          <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image"/>
                        </div>
                        <h4>
                          Support Team
                          <small><i class="fa fa-clock-o"></i> 5 mins</small>
                        </h4>
                        <p>Why not buy a new awesome theme?</p>
                      </a>
                    </li><!-- end message -->
                    <li>
                      <a href="#">
                        <div class="pull-left">
                          <img src="dist/img/user3-128x128.jpg" class="img-circle" alt="user image"/>
                        </div>
                        <h4>
                          AdminLTE Design Team
                          <small><i class="fa fa-clock-o"></i> 2 hours</small>
                        </h4>
                        <p>Why not buy a new awesome theme?</p>
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <div class="pull-left">
                          <img src="dist/img/user4-128x128.jpg" class="img-circle" alt="user image"/>
                        </div>
                        <h4>
                          Developers
                          <small><i class="fa fa-clock-o"></i> Today</small>
                        </h4>
                        <p>Why not buy a new awesome theme?</p>
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <div class="pull-left">
                          <img src="dist/img/user3-128x128.jpg" class="img-circle" alt="user image"/>
                        </div>
                        <h4>
                          Sales Department
                          <small><i class="fa fa-clock-o"></i> Yesterday</small>
                        </h4>
                        <p>Why not buy a new awesome theme?</p>
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <div class="pull-left">
                          <img src="dist/img/user4-128x128.jpg" class="img-circle" alt="user image"/>
                        </div>
                        <h4>
                          Reviewers
                          <small><i class="fa fa-clock-o"></i> 2 days</small>
                        </h4>
                        <p>Why not buy a new awesome theme?</p>
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="footer"><a href="#">See All Messages</a></li>
              </ul>
            </li>
            <!-- Notifications: style can be found in dropdown.less -->
            <li class="dropdown notifications-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-bell-o"></i>
                <span class="label label-warning">10</span>
              </a>
              <ul class="dropdown-menu">
                <li class="header">You have 10 notifications</li>
                <li>
                  <!-- inner menu: contains the actual data -->
                  <ul class="menu">
                    <li>
                      <a href="#">
                        <i class="fa fa-users text-aqua"></i> 5 new members joined today
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-warning text-yellow"></i> Very long description here that may not fit into the page and may cause design problems
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-users text-red"></i> 5 new members joined
                      </a>
                    </li>

                    <li>
                      <a href="#">
                        <i class="fa fa-shopping-cart text-green"></i> 25 sales made
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-user text-red"></i> You changed your username
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="footer"><a href="#">View all</a></li>
              </ul>
            </li>
            
            <!-- User Account: style can be found in dropdown.less -->
            <li class="dropdown user user-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <img src="../assets/img/team/<?php echo($fetch_account['image']); ?>" class="user-image" alt="User Image"/>
                <span class="hidden-xs"><?php echo($names); ?></span>
              </a>
              <ul class="dropdown-menu">
                <!-- User image -->
                <li class="user-header">
                  <img src="../assets/img/team/<?php echo($fetch_account['image']); ?>" class="img-circle" alt="User Image" />
                  <p>
                    <?php echo($names); ?> - Web Developer
                    <small>Member since <?php $nowtime=$fetch_account['Join_date'];
                    print date("M d,Y (D)",$nowtime); ?></small>
                  </p>
                </li>
                <!-- Menu Body -->
                
                <!-- Menu Footer-->
                <li class="user-footer">
                  <div class="pull-left">
                    <a href="#" class="btn btn-default btn-flat">Profile</a>
                  </div>
                  <div class="pull-right">
                    <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                  </div>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
          <div class="pull-left image">
            <img src="../assets/img/team/<?php echo($fetch_account['image']); ?>" class="img-circle" alt="User Image" />
          </div>
          <div class="pull-left info">
            <p><?php echo($names); ?></p>

            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
          </div>
        </div>
        <!-- search form -->
        <form action="#" method="get" class="sidebar-form">
          <div class="input-group">
            <input type="text" name="q" class="form-control" placeholder="Search..."/>
            <span class="input-group-btn">
              <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
            </span>
          </div>
        </form>
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
          <li class="header">MAIN NAVIGATION</li>
          <li <?php if($active_page=='dashboard'){ echo 'class="active"'; } ?>>
            <a href="index.php">
              <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
            </a>
            <!-- <ul class="treeview-menu">
              <li><a href="index.html"><i class="fa fa-circle-o"></i> Dashboard v1</a></li>
              <li class="active"><a href="index.php"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>
            </ul> -->
          </li>
          <?php if($admin=='1'){ ?>
          <li <?php if($active_page=='users'){ echo 'class="active"'; } ?>>
            <a href="user.php">
              <i class="fa fa-th"></i> <span>Users</span> <small class="label pull-right bg-blue">Admin</small>
            </a>
          </li>
          <?php  } ?>
          <li <?php if($active_page=='applicants'){ echo 'class="active"'; } ?>>
            <a href="applicants.php">
              <i class="fa fa-list"></i> <span>Citizens</span> <small class="label pull-right bg-green">Applicants</small>
            </a>
          </li>
          
          <!-- <li><a href="documentation/index.html"><i class="fa fa-book"></i> Documentation</a></li> -->
          <li class="header">LABELS</li>
          <li><a href="#"><i class="fa fa-circle-o text-danger"></i> Important</a></li>
          <li><a href="#"><i class="fa fa-circle-o text-warning"></i> Warning</a></li>
          <li><a href="#"><i class="fa fa-circle-o text-info"></i> Information</a></li>
        </ul>
      </section>
      <!-- /.sidebar -->
    </aside>