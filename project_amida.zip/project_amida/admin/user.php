<?php
session_start();
?>
<?php
if(!isset($_SESSION["DA_user"])){
echo("<script>location.href='login.html';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
//  echo("<script>location.href='lock.php';</script>");
}
else{

    include('connection.php'); 
$account_key=$_SESSION["DA_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];
$admin=$fetch_account['admin_account'];

$todayyear=date("Y");
// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_account['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Duhamic-Adri | Users</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
    <?php 
$active_page='users';
include'header.php';?>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Project Managers
            <small>preview of simple tables</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Users</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            
        <div class="col-md-4">
              <!-- Info Boxes Style 2 -->
              <div class="info-box bg-yellow">
                <span class="info-box-icon"> 
                  <a data-toggle="modal" data-target="#adduser" title="ADD a District">
                    
                  
                  <span class="info-box-icon"><span class="glyphicon glyphicon-user"></span></span>
                  </a></span>
                <div class="info-box-content">
                  <span class="info-box-text">Users/Project Manager(s)</span>
                  <span class="info-box-number"><?php echo $count_all_users; ?></span>
                  <div class="progress">
                    <div class="progress-bar" style="width: 50%"></div>
                  </div>
                  <span class="progress-description">
                    50% Increase in 30 Days
                  </span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
              <div class="example-modal modal fade" id="adduser" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-primary">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">ADD A New user(Project Manager)</h4>
                  </div>
                  <div class="modal-body">
                          <!--New User Form -->
              <form class="row g-3 needs-validation" name="user_form" id="user_form" action="" method="POST" >

                <div class="col-md-6">
                  <label for="validationCustom01" class="form-label">First name</label>
                  <input type="text" class="form-control" id="fname" name="fname"  placeholder="your First name..." required>
                </div>
                <div class="col-md-6">
                  <label for="validationCustom02" class="form-label">Last name</label>
                  <input type="text" class="form-control" id="lname" name="lname" placeholder="your Last name..."  required>
                </div>
                <div class="col-md-6">
                  <label for="validationCustomUsername" class="form-label">Username</label>
                    <input type="text" class="form-control" id="UniqueName" placeholder="duhamic user name..." aria-describedby="inputGroupPrepend" name="UniqueName" required>
                        </div>
                  <div class="col-md-6">
                  <label for="validationCustom05" class="form-label">Gender</label>
                  <fieldset class="row">
                  <div class="col-sm-10">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="gender" id="gridRadios1" value="user" checked>
                      <label class="form-check-label" for="gridRadios1">
                      Male
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="gender" id="gridRadios2" value="Female">
                      <label class="form-check-label" for="gridRadios2">
                      Female
                      </label>
                    </div>
                  </div>
                </fieldset>
                </div>
                <div class="col-md-12">
                  <label for="validationCustomUsername" class="form-label">User ID/email</label>
                    <input type="email" class="form-control" id="UserId" placeholder="email..." aria-describedby="inputGroupPrepend" Name="UserId" required>
                     </div>
                <div class="col-md-6">
                  <label for="validationCustom04" class="form-label">Location</label>
                  <select class="form-control" id="validationCustom04" name="ulocation" required>
                    <option selected  value="">Choose Location...</option>
                    <?php
                  $sel_locations=$con->query("SELECT*from locations ")or die($con->error);
                  while($fetch_locations=$sel_locations->fetch_assoc()){ ?>
                <option value="<?php echo $fetch_locations['id'] ?>" ><?php echo $fetch_locations['District'] ?></option>
                    <?php }  ?>
                    </select>
                
                </div>
                <div class="col-md-6">
                  <label for="validationCustom05" class="form-label">Account-Type</label>
                  <fieldset class="row mb-3">
                  
                  <div class="col-sm-10">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="Rtype" id="gridRadios1" value="user" checked>
                      <label class="form-check-label" for="gridRadios1">
                      User
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="Rtype" id="gridRadios2" value="Manager">
                      <label class="form-check-label" for="gridRadios2">
                      Admin
                      </label>
                    </div>
                  </div>
                </fieldset>
                
                </div>
                <div class="col-md-12">
                  
                  <div class="input-group has-validation">
                    <span class="input-group-text" id="inputGroupPrepend">Default U.Password</span>
                    <input type="text" class="form-control" id="validationCustomUsername" value="Duhamic@123" aria-describedby="inputGroupPrepend" Name="Dpass" required>
                    <div class="invalid-feedback">
                      Please Decide a User Password.
                    </div>
                  </div>
                  </div>

                  <div class="col-md-12">
                  <label for="validationCustom04" class="form-label">Assign the User to the Project</label>
                  <select class="form-control" id="validationCustom04" name="Project" required>
                    <option selected  value="">Choose Project...</option>
                    <?php
                  $sel_programs=$con->query("SELECT*from programs ")or die($con->error);
                  while($fetch_programs=$sel_programs->fetch_assoc()){ ?>
                <option value="<?php echo $fetch_programs['id'] ?>" ><?php echo $fetch_programs['P_tittle'] ?></option>
                    <?php }  ?>
                               
                  </select>
                
                </div>

                <div class="col-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                    <label class="form-check-label" for="invalidCheck">
                      Agree to terms and conditions
                    </label>
                    
                  </div>
                </div>
               <div id="usermsg" class="pull-center" >Message</div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" name="saveUser" id="saveUser" class="btn btn-outline" >Save changes</button>
                                     

                  </form>
                  </div>
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
          </div><!-- /.example-modal -->
                  </div>

          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">List Of Employees</h3>
                  <div class="box-tools">
                    <div class="input-group">
                      <input type="text" name="table_search" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                      <div class="input-group-btn">
                        <button class="btn btn-sm btn-default"><i class="fa fa-search"></i></button>
                      </div>
                    </div>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                      <th>#</th>
                      <th>User / Names</th>
                      <th>Date</th>
                      <th>Status</th>
                      <th>Address</th>
                    </tr>
                    <?php  
                       $count=0;
                       while($fetch_users=$sel_all_users->fetch_assoc()){ 
                        $count++;
                       ?>
                    <tr>
                      <td><?php echo $count; ?></td>
                      <td><?php echo $fetch_users['fname']." ".$fetch_users['lname']."<br>".$fetch_users['user_name']; ?>
                      <?php
                      if($fetch_users['id']==$account_key){
                      ?><span class="label label-warning">Me</span>
                      <?php } ?>
                      </td>
                      <td><?php $jointime=$fetch_users['Join_date'];
                        print date("M d, Y (D)",$jointime); ?></td>
                      <td><?php
                      if($fetch_users['admin_account']==1){
                      ?><span class="label label-primary">ADMIN</span>
                      <?php }else{ ?>
                        <span class="label label-success">User</span>
                        <?php } ?>
                      </td>
                      <td><?php echo $fetch_users['email']; ?></td>
                    </tr>
                    <?php }?>
                    
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      < <footer class="main-footer">
        <div class="pull-right hidden-xs">
         
        </div>
        <strong>Copyright &copy; 2022 <a href="#">DuhamicAdri</a>.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
  </body>
</html>
