<?php
session_start();
?>
<?php
if(!isset($_SESSION["DA_user"])){
    echo '<label color="red">You are not Authorized<br> It seems your session expired</label>';
echo("<script>location.href='login.html';</script>");
// }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
//  echo("<script>location.href='lock.php';</script>");
echo '<label color="red">You are not Authorized</label>';
}
else{

    include('connection.php'); 
$account_key=$_SESSION["DA_user"];
$sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['user_name'];
$myemail=$fetch_account['email'];

$todayyear=date("Y");

// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_account['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

}
//citizen.php
require_once('connection.php');



if(isset($_POST['newdistrict']))
{
  $locprovince=$_POST['locprovince'];
  $locprovince=str_replace("'", "\'", $locprovince);
  $newdistrict=$_POST['newdistrict'];
  $newdistrict=str_replace("'", "\'",  $newdistrict);
 

    
    $now=time();
   

    $sel_availables=$con->query("SELECT*from locations where District='$newdistrict' or District='$locprovince'  ")or die($con->error);
    if($count_availables=$sel_availables->num_rows>0){
      echo '<label style="color:red;">District: '.$newdistrict.' Are already in the system<br />Please Provide Differnt Location </label>';
     $alert="District: '.$newdistrict.' Are already in the system<br />Please Provide Differnt Location";
    }

    

    if(!isset($alert)){
      $savequery=$con->query("INSERT INTO locations(District,province,added_by,created_date) VALUES ('$newdistrict','$locprovince','$account_key','$now')")or die($con->error);
      if ($savequery) {
          $approvo="New Member is added in System Please complete all related info!<br> ";
          // $_SESSION["new_member"] = $sku;
          echo '<label style="color:Blue;">Success<br />'.$newdistrict.' District is now a location</label>';
          //$saveactivity=$con->query("INSERT INTO activity(activity_by,tittle,category,information,event_time) VALUES ('$account_key','New Name has been Added','info','New name: $fName. has been added to the system','$now')")or die($con->error);
     

          // if(isset($_SESSION["new_member"])){
          //   echo("<script>location.href='new_2.php';</script>");
          //  }
          // sleep(7);
          echo("<script>location.href='index.php?info=New  $newdistrict District is now a location';</script>");
         
             } 
    }

   }else if(isset($_POST['UserId'])){

    if(empty($_POST['UniqueName']) ||empty($_POST['lname']) ||empty($_POST['UserId'])){
        $info="Please Fill All Important information the Blanks,<br> Every box must contain Relevant details";
      }else{
        $Username= $_POST['UniqueName'];
        $Username=str_replace("'", "\'",   $Username);
        $UserId= $_POST['UserId'];
        $lname= $_POST['lname'];
        $lname=str_replace("'", "\'",   $lname);
        $fname= $_POST['fname'];
        $fname=str_replace("'", "\'",   $fname);
        $ulocation= $_POST['ulocation'];
        $ulocation=str_replace("'", "\'",   $ulocation);
        $Project= $_POST['Project'];
        $Project=str_replace("'", "\'", $Project);
        $Dpass= $_POST['Dpass'];
        $security=md5($Dpass);
        
        $Rtype= $_POST['Rtype'];
        if($Rtype=='Manager'){
          $anadmin=1;
        }else{
          $anadmin=0;
        }

        $gender= $_POST['gender'];

        if($gender=='male'){
          $image='avatar_male.png';
        }else{
          $image='avatar_female.png';
        }
  
        $now=time();
  
        $sel_availables=$con->query("SELECT*from users where user_name='$Username' ")or die($con->error);
        if($count_availables=$sel_availables->num_rows>0){
         $alert="A Username ' ".$Username." ' Is taken <br>Choose a different name as User names should be Unique!";
        }
  
        if(!isset($alert)){
            $savequery=$con->query("INSERT INTO users(user_name,fname,lname,Join_date,email,password,status,duties,admin_account,image) VALUES ('$Username','$fname','$lname','$now','$UserId','$security','Offline','$Project','$anadmin','$image')")or die($con->error);
            if ($savequery){
                $approvo="New Member is added in System Please complete all related info!<br> ";

                $sel_availables=$con->query("SELECT*from users where user_name='$Username' ")or die($con->error);
                if($count_search=$sel_availables->num_rows>0){
                  $fetch_thenew=$sel_availables->fetch_assoc();
                  $thisguy=$fetch_thenew['id'];
                }
          
                $saveactivity=$con->query("INSERT INTO messages(type,tittle,event_time,msg_to,msg_from) VALUES ('Alert','You have been Registered','$now','$Username','$names')")or die($con->error);
           
                       // $names=$_POST['names'];
          //$content=$_POST['content'];
          $to =$UserId;
          $subject = 'New Member is initiated in Duhamic-Adri';
          $message= '<p style="color:#4c5a7d"> Hello '.$lname.' , </p>';
          $message .= '<p>This is to inform that  </p>';
          $message .= '<p>New account is Created, Use the Below Credentials to Log in Your Account: </p>';
          $message .= '<p> User Name:'.$Username.'</p>';
          $message .= '<p> Email/ID: '.$UserId.'</p>';
          $message .= '<p> Default Password: '.$Dpass.'<small> Note that you will be Required to update This Right on the Loggin</small></p>';
          
          if(isset($alert)){
            $message .= '<p> Belows are Some Errors Occured:</p>';
          $message .= '<p> Errors:'.$alert.'</p>';
          }else{
            $message .= '<p> Thank you!</p>';
          }
          $message .= '<p> ------------------------------------------------------------------------------</p>';
          $message .= '<p>  If this was you, you don’t need to do anything. If not, we’ll help you secure your account. call Us now
           <a href="tel:+250786193917"> (+250) 786 193 917 </a> or just Reply to <b>doknge@gmail.com</b>!</p>';
          
          $headers = "From: Duhamic-Adri Rwanda \r\n";
          $headers .= "Reply-To: doknge@gmail.com\r\n";
          
          $headers .= "Content-type: text/html\r\n";
          
          $send=mail($to, $subject, $message, $headers);
          
          if($send){
            $approvo .="New Member is added in System Please complete all related info!<br> ";
          }else{
            $info="Email sending failed!";
          }
          if(isset($approvo)){
            echo '<div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p>'.$approvo.'</p>
          </div>';
            echo("<script>location.href='index.php?info=$approvo';</script>");
          }
          
                   } 
          }else{
            echo '<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <p>'.$alert.'</p>
          </div>';
          }
  
    }
  }//====Closing The SaveUser============
  else if(isset($_POST['Pname'])){
    
    $pname=$_POST['Pname'];
    $pname=str_replace("'", "\'", $pname);
    $ulocation= $_POST['ulocation'];
    $pmanager= $_POST['pmanager'];

    $now=time();
  
        $sel_availables=$con->query("SELECT*from programs where P_tittle='$pname' and location='$ulocation' ")or die($con->error);
        if($count_availables=$sel_availables->num_rows>0){
         $alert="The project is not allowed twice in the same District <br>You may want to select the Different District!";
        }

        if(!isset($alert)){
          $savequery=$con->query("INSERT INTO programs(P_tittle,responsible_user,location,initiated_on,Status) VALUES ('$pname','$pmanager','$ulocation','$now','Planned')")or die($con->error);
          if ($savequery){
              $approvo="New Project Has just innitiated!<br> ";

              $sel_availables=$con->query("SELECT*from users where id='$pmanager' ")or die($con->error);
              if($count_search=$sel_availables->num_rows>0){
                $fetch_thenew=$sel_availables->fetch_assoc();
                $thisguy=$fetch_thenew['id'];
                $Username=$fetch_thenew['user_name'];
                $saveactivity=$con->query("INSERT INTO messages(type,tittle,event_time,msg_to,msg_from) VALUES ('Alert','You have been assigned to the Project','$now','$Username','$names')")or die($con->error);
         
              }
        
              
            
            if(isset($approvo)){
              echo '<div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <p>'.$approvo.'</p>
            </div>';
              echo("<script>location.href='index.php?info=$approvo';</script>");
            }
            
                     } 
            }else{
              echo '<div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <p>'.$alert.'</p>
            </div>';
            } 
          }
          else{
     echo '<label>Not Setted</label>';
                   } ?>