<?php
session_start();

require_once('connection.php');

if(isset($_POST['loginname']))
{

  $name=$_POST['loginname'];
  

  if(empty($_POST['loginname']) ||empty($_POST['password']))

  {
    //echo("<div class='error_message btn-primary text-center'>Please Fill in the Blanks.</div><br/>"); 
      echo("<span class='badge border-primary border-1 text-primary'>Please Fill in the Blanks.</span>");
    
  }
  else{
 $username = $_POST['loginname'];
     $pass = md5($_POST['password']);

    $query="select * from  users  where password='".$pass."' and user_name='".$username."' or password='".$pass."' and email='".$username."' ";
    $result=mysqli_query($con,$query);
    if(mysqli_fetch_assoc($result))
    {
$view_p=$con->query("SELECT * from users where  password='$pass' and  user_name='$username' or password='$pass' and email='$username'")or die("Connection failed: " . $con->connect_error);
      $view=$view_p->fetch_assoc();
      //$id=$view['store_No'];
      $last_seen=time();
      $_SESSION["DA_user"] = $view['id'];
      //$_SESSION["access"] = $view['account_type'];
      $_SESSION["last_seen"] = $last_seen;
//=========LOGIN Cookies=================
      // if (!empty($_POST["remember"])) {
      //   setcookie("care_login",$_POST['loginname'],time()+ (10 * 365 * 24 * 60 * 60));
      //   setcookie("care_password",$_POST['password'],time()+ (10 * 365 * 24 * 60 * 60));
      //   # code...
      // }else{
      //   if(isset($_COOKIE["care_login"]))
      //   {
      //     setcookie("care_login","");
      //   }
      //   if(isset($_COOKIE["care_password"]))
      //   {
      //     setcookie("care_password","");
      //   }

      // }
      //====Cookie ends here====
//       if($view['account_type']=='Manager'){
//       $_SESSION["Manager"] =$view['user_name'];    
//  }

 $query=$con->query("UPDATE users SET status='Online',last_seen='$last_seen' WHERE id ='".$view['id']."' ")or die($con->error);
      
      echo("<script>location.href='index.php?load&user=".$view['user_name']."';</script>");  
    }
    else{
 //echo("<div class='error_message btn-danger text-center'>Invalid!<br> Enter Correct User name/email OR Password.</div><br/>");

 echo("<p class='text-center text-danger'>Invalid User name/email OR Password.</p>");
    }
  }

// else{
// echo("<div class='error_message text-center'>login.</div><br/>");
// }
}else{
  echo("<p class='text-center small'>Enter your username & password to login</p>");
}

//ob_flush();
?>