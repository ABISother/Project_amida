<?php
if(isset($_POST['submitrequest'])){
  require_once('connection.php');
  $manager_id=$_POST['manager_id'];
  $project_name=$_POST['pname'];
  $project_name=str_replace("'", "\'", $project_name);
  $applicant_id= $_POST['applicant_id'];
  $program_id= $_POST['program_id'];

  $now=time();

      $sel_availables=$con->query("SELECT*from applicants where applicant_id='$applicant_id' and program_id='$program_id' ")or die($con->error);
      if($count_availables=$sel_availables->num_rows>0){
       $alert="You have already applied to This project is not allowed twice in the same District <br>You may want to select the Different Project!";
      }

      if(!isset($alert)){
        $savequery=$con->query("INSERT INTO applicants(applicant_id,program_id,	program_manager,regist_date,status) VALUES ('$applicant_id','$program_id','$manager_id','$now','Received')")or die($con->error);
        if ($savequery){
            $approvo="Your Registration to Project of ".$project_name." have been Received! <br> Thank you ";

        
          
                   } 
          }
        }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Search - DUHAMIC-ADRI</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

   <!-- Favicons -->
   <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/logo.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
   * Project Name: AMAJYAMBERE Y’ICYARO ANALYTIC AND MANAGEMENT SYSTEM
  * Author: NIKUZE Amida
  * License: +250784561732
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php 
  include('header.php');
  ?><!-- End Header -->
  <!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs">
      <div class="page-header d-flex align-items-center" style="background-image: url('assets/img/DUHA.jpg');">
        <div class="container position-relative">
          <div class="row d-flex justify-content-center">
            <div class="col-lg-4 text-center">
             
              <?php if(!isset($_POST['searchid'])){
                echo("<script>location.href='index.php?alert=Please use your ID to search Programs in Your location!';</script>");
              }else{
                include('connection.php'); 
                $search_key=$_POST['searchid'];
                $sel_search=$con->query("SELECT*from citizens WHERE program_id='$search_key' ")or die($con->error);
                if($count_search=$sel_search->num_rows>0){
                $fetch_search=$sel_search->fetch_assoc();
                $names=$fetch_search['fname']." ".$fetch_search['lname'];
                $searchdistrict=$fetch_search['district_name'];
                $districtid=$fetch_search['district'];
                 
                            $sel_locations=$con->query("SELECT*from locations where id='$districtid' ")or die($con->error);
                            $fetch_district=$sel_locations->fetch_assoc();
                            $district=$fetch_district['District'];
                            
                $today=date(" M d, Y");
                $todayyear=date("Y");
                $time=date("h:i a");
              }else{
                echo("<script>location.href='index.php?alert=Invalid ID:$search_key,<br>Please remember your Program ID!';</script>");
                echo("<p>If There is any Message will appear here.</p>");
              } }?>
               <h2><?php echo $district; ?></h2>
              <p>Hello <?php echo $fetch_search['fname']; ?>, You will find below all programs available in your Village/District (<?php echo $district; ?>).</p>
              <p><i class="bi bi-chevron-down dropdown-indicator"></i></p>
            </div>
          </div>
        </div>
      </div>
      <nav>
        <div class="container">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Results</li>
          </ol>
        </div>
      </nav>
    </div><!-- End Breadcrumbs -->

  <?php
  if(isset($approvo)){
    echo '<div class="alert alert-success alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <p>'.$approvo.'</p>
  </div>';
    //echo("<script>location.href='index.php?info=$approvo';</script>");
  }
  if(isset($alert)){
    echo '<div class="alert alert-danger alert-dismissable">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <p>'.$alert.'</p>
  </div>';
  } 
  ?>

    <!-- ======= Horizontal Pricing Section ======= -->
    <section id="horizontal-pricing" class="horizontal-pricing pt-0">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <span><?php echo $fetch_search['program_id']  ?></span>
          <h2><?php echo $names  ?></h2>

        </div>
              <?php $sel_program=$con->query("SELECT*from programs WHERE location='$districtid' ")or die($con->error);
                $count_program=$sel_program->num_rows;
                if($count_program>0){
                //Number of locations this user has responsed to work on
                  $locations=$count_program;
                  
                  while($fetch_program=$sel_program->fetch_assoc()){
                    $program_id=$fetch_program['id'];
                    $applicant=$fetch_search['id'];

        $sel_req_availables=$con->query("SELECT*from applicants where applicant_id='$applicant' and program_id='$program_id' ")or die($con->error);
      if($count_req_availables=$sel_req_availables->num_rows>0){
        $requested=$sel_req_availables->fetch_assoc();
       
      }

                 ?>
        <div class="row gy-4 pricing-item <?php if(isset($requested)){ echo "featured mt-4";} ?>" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <h3><?php echo $fetch_program['P_tittle']  ?></h3>
          </div>
          <div class="col-lg-2 d-flex align-items-center justify-content-center">
            <span><?php echo $district; ?></span>,
            <h5><span> <?php $nowtime=$fetch_program['initiated_on'];
                    print date("D, d/m/Y",$nowtime); ?></span></h5>
          </div>
          
          <div class="col-lg-2 d-flex align-items-center justify-content-center">
            <ul>
              <li><i class="bi bi-check"></i> Program initiated </li>
              <li><i class="bi bi-check"></i> Requirements</li>
              <?php if(isset($requested)){ 
                echo '<li ><i class="bi bi-check"></i> <span>Applied to The Program</span></li>';}else{
                  echo'<li class="na"><i class="bi bi-x"></i> <span>I am registered to Program</span></li>';
                } ?>
              
            </ul>
          </div>
          <?php if(isset($requested)){ ?>
          <div class="col-lg-2 d-flex align-items-center justify-content-center">
            <div class="text-center"><label  class="buy-btn small">Request <?php echo $requested['status']; ?></label></div>
          </div>
          <?php }else{ ?>
            <div class="col-lg-2 d-flex align-items-center justify-content-center">
            <div class="text-center"><a type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-<?php echo $fetch_program['id']  ?>" class="buy-btn small">Regist</a></div>
          </div>
            <?php } ?>
          
          <div id="faq-content-<?php echo $fetch_program['id']  ?>" class="accordion-collapse collapse" data-bs-parent="#faqlist">
            <form id="regist" action="" method="post" >
            <div class="col-md-6">
              
              <input type="hidden" class="form-control" id="searchid" name="searchid" value="<?php echo $search_key  ?>"  placeholder="your First name..." required>
            </div>
            <div class="col-md-6">
              
              <input type="hidden" class="form-control" id="pname" name="pname" value="<?php echo $fetch_program['P_tittle']  ?>"  placeholder="your First name..." required>
            </div>
            <div class="col-md-6">
              
                  <input type="hidden" class="form-control" id="program_id" name="program_id" value="<?php echo $fetch_program['id']  ?>"  placeholder="your First name..." required>
                </div>
                <div class="col-md-6">
                  <input type="hidden" class="form-control" id="applicant_id" name="applicant_id" value="<?php echo $fetch_search['id']  ?>"  placeholder="your First name..." required>
                </div>
                <div class="col-md-6">
                  <input type="hidden" class="form-control" id="manager_id" name="manager_id" value="<?php echo $fetch_program['responsible_user']  ?>"  placeholder="your First name..." required>
                </div>
                  <div class="accordion-body">
                    <?php echo $fetch_program['details']  ?>  
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                    <label class="form-check-label" for="invalidCheck">
                     I <?php echo $names  ?>, Agree to terms and conditions
                    </label>
                    </div>
                    <div class="">
                    <button type="submit" name="submitrequest" id="saveUser" class="buy-btn btn-outline" >Send Application</button>
                  </div>
               </form>
                </div>

        </div><!-- End Pricing Item -->
      
            <?php  } } else{
                  $locations=0;
                  echo '  <div class="row gy-4 pricing-item" data-aos="fade-up" data-aos-delay="100">
                  <div class="d-flex align-items-center justify-content-center">
                    <h3>There are no Programs in your Location For Now</h3>
                  </div>
                 
                  
                </div>';
                } ?>
        

      

      </div>
    </section><!-- End Horizontal Pricing Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php 
  include('footer.php');
  ?><!-- End Footer -->
  <!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>