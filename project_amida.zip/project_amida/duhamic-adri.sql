-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2022 at 01:00 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `duhamic-adri`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `program_manager` int(11) NOT NULL,
  `regist_date` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL,
  `aprooved` tinyint(1) NOT NULL DEFAULT 0,
  `deny_reason` varchar(90) NOT NULL DEFAULT 'Not carrified',
  `approvo_date` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`id`, `applicant_id`, `program_id`, `program_manager`, `regist_date`, `status`, `aprooved`, `deny_reason`, `approvo_date`) VALUES
(1, 22, 4, 1, '1664134523', 'Approved', 0, 'We are Reviewing the Requirement, We will come to you shortly!', '1664149637'),
(2, 23, 2, 2, '1664189667', 'Received', 0, 'Not carrified', ''),
(3, 22, 1, 1, '1664190404', 'Received', 0, 'Not carrified', '');

-- --------------------------------------------------------

--
-- Table structure for table `citizens`
--

CREATE TABLE `citizens` (
  `id` int(11) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `program_id` decimal(60,0) NOT NULL,
  `telephone` varchar(10) NOT NULL,
  `email` varchar(60) NOT NULL,
  `district` int(11) NOT NULL DEFAULT 1,
  `district_name` varchar(60) NOT NULL DEFAULT 'Kicukiro',
  `birthdate` varchar(60) NOT NULL,
  `join_date` varchar(60) NOT NULL,
  `registered_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `citizens`
--

INSERT INTO `citizens` (`id`, `fname`, `lname`, `gender`, `program_id`, `telephone`, `email`, `district`, `district_name`, `birthdate`, `join_date`, `registered_by`) VALUES
(13, 'ABI', ' ERER', 'Male', '120081472698305', '0785318962', 'abirihosother@gmail.com', 3, '1', '1202770800', '1663705132', 1),
(14, 'Teddy', ' Girl', 'Female', '119930916852347', '0785318912', 'teddy@gmail.com', 5, '1', '734652000', '1663705695', 1),
(15, 'Uwizeye', ' Pacifique', 'Male', '119983078254691', '0784676123', 'uwipacy@gmail.com', 4, '1', '894924000', '1664051840', 1),
(16, 'Giramata', ' Christella', 'Female', '119966947025381', '0782342343', 'giramata@gmail.com', 6, '', '842479200', '1664063579', 1),
(17, 'cassez', ' airtel', 'Male', '120097436801592', '0784534534', 'cassez@gmail.com', 7, '', '1252706400', '1664065792', 1),
(18, 'Giramata', ' Savior', 'Female', '120133940821675', '0785318961', 'theo@gmail.com', 4, '', '1358722800', '1664066340', 1),
(19, 'maniriho', ' theophile', 'Male', '120072918756340', '0785318963', 'theo@gmail.com', 2, '', '1167606000', '1664066827', 1),
(20, 'CLARISSE', ' muneza', 'Female', '120076309751284', '0787848962', 'theo@gmail.com', 3, 'Rwamagana', '1171148400', '1664072311', 1),
(21, 'CLARISSE', ' Mahoro', 'Female', '120085374168092', '0785367896', 'sother@gmail.com', 8, 'Gakenke', '1199314800', '1664073041', 1),
(22, 'Giramata', ' HONOLINE', 'Female', '119782519384067', '0785334556', 'GIRAMATA@gmail.com', 1, 'Kicukiro', '265676400', '1664075432', 1),
(23, 'umwali ', ' ange', 'Female', '120070912364875', '0789999', 'ange@gmail.com', 8, 'Gakenke', '1167606000', '1664189446', 1),
(24, 'nziza', ' anne', 'Female', '120089256087143', '07896543', 'anne@gmail.com', 9, 'Butare', '1209765600', '1664190499', 1),
(25, 'bwiza', ' oda', 'Female', '120064598301267', '0784561732', 'oda@gmail.com', 9, 'Butare', '1159999200', '1664190641', 1);

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` int(11) NOT NULL,
  `payid` varchar(60) NOT NULL,
  `date_of_trans` varchar(60) NOT NULL,
  `Donator_names` varchar(60) NOT NULL,
  `donor_phone` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL,
  `donate_for` varchar(60) NOT NULL,
  `comments` varchar(90) NOT NULL,
  `new_donor` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `payid`, `date_of_trans`, `Donator_names`, `donor_phone`, `amount`, `donate_for`, `comments`, `new_donor`) VALUES
(1, 'DA6079', '1663539334', 'SOTHER', '0784624822', 20000, '0', 'hello', 1),
(2, 'DA9547', '1663539354', 'SOTHER', '0784624822', 20000, '0', 'hello', 1),
(3, 'DA0249', '1663539438', 'SOTHER', '0784624822', 20000, '0', 'hello', 1),
(4, 'DA0648', '1663539440', 'SOTHER', '0784624822', 20000, '0', 'hello', 1),
(5, 'DA8139', '1663539449', 'SOTHER', '0784624822', 30000, '0', 'hello', 1),
(6, 'DA7345', '1663539866', 'SOTHER', '0784624821', 30000, '1', 'hello', 1),
(7, 'DA4135', '1663539868', 'SOTHER', '0784624821', 30000, '1', 'hello', 0);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `District` varchar(60) NOT NULL,
  `province` varchar(60) NOT NULL,
  `added_by` int(11) NOT NULL DEFAULT 1,
  `created_date` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `District`, `province`, `added_by`, `created_date`) VALUES
(1, 'Kicukiro', 'Kigali', 1, '1658356712'),
(2, 'Gasabo', 'Kigali', 1, '1658356712'),
(3, 'Rwamagana', 'Eastern Province', 1, '1658356712'),
(4, 'Rutsiro', 'Western Province', 1, '1658356712'),
(5, 'Rubavu', 'western province', 1, '1658356712'),
(6, 'Nyamagabe', 'South', 1, '1658356712'),
(7, 'Musanze', 'Northern', 1, '1663719065'),
(8, 'Gakenke', 'Northern', 1, '1663719280'),
(9, 'Butare', 'South', 1, '1663976245'),
(10, 'Nyagatare', 'Eastern', 1, '1664063127'),
(11, 'Byumba', 'Northern', 1, '1664072744'),
(12, 'nyabihu', 'west', 1, '1664190766');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `type` varchar(60) NOT NULL DEFAULT 'Alert',
  `tittle` varchar(90) NOT NULL,
  `event_time` varchar(60) NOT NULL,
  `msg_to` varchar(60) NOT NULL,
  `msg_from` varchar(60) NOT NULL,
  `msg_seen` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `type`, `tittle`, `event_time`, `msg_to`, `msg_from`, `msg_seen`) VALUES
(2, 'Alert', 'You have been Registered', '1663991239', '0', '0', 0),
(3, 'Alert', 'You have been assigned to the Project', '1664033392', 'Ange', 'amida', 0),
(4, 'Alert', 'You have been assigned to the Project', '1664072721', 'Ange', 'amida', 0),
(5, 'Alert', 'You have been assigned to the Project', '1664079267', 'amida', 'amida', 0),
(6, 'Alert', 'You have been Registered', '1664188878', 'abi', 'amida', 0),
(7, 'Alert', 'You have been Registered', '1664189188', 'tsamy', 'amida', 0),
(8, 'Alert', 'You have been assigned to the Project', '1664189772', 'Ange', 'amida', 0);

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` int(11) NOT NULL,
  `P_tittle` varchar(100) NOT NULL,
  `responsible_user` int(11) NOT NULL,
  `location` int(11) NOT NULL,
  `initiated_on` varchar(60) NOT NULL,
  `details` varchar(300) NOT NULL,
  `Status` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `P_tittle`, `responsible_user`, `location`, `initiated_on`, `details`, `Status`) VALUES
(1, 'Agriculture (Value chain: maize, soya, fruit, rice)', 1, 1, '1323432453454564', '', ''),
(2, 'Training of farmers', 2, 8, '1664033392', '', 'Planned'),
(3, 'Animal breeding', 2, 6, '1664072721', '', 'Planned'),
(4, 'Animal breeding', 1, 1, '1664079267', '', 'Planned'),
(5, 'livestock', 2, 8, '1664189772', '', 'Planned');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `Join_date` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `first_login` tinyint(1) NOT NULL DEFAULT 0,
  `last_seen` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL,
  `duties` varchar(100) NOT NULL,
  `admin_account` tinyint(1) NOT NULL DEFAULT 0,
  `image` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `fname`, `lname`, `Join_date`, `email`, `password`, `first_login`, `last_seen`, `status`, `duties`, `admin_account`, `image`) VALUES
(1, 'amida', 'NIKUZE', 'Amida', '1649272407', 'amida@gmail.com', '202cb962ac59075b964b07152d234b70', 0, '1669117039', 'Online', '', 1, 'avatar_male.png'),
(2, 'Ange', 'MUTONI', 'Ange', '1652199010', 'dokange@gmail.com', '202cb962ac59075b964b07152d234b70', 0, '1664151441', 'Online', '', 0, 'avatar_male.png'),
(3, 'Theo', 'maniriho', 'theophile', '1663988935', 'theo@gmail.com', '4397fc1ee31902af8ef26eec0a917082', 0, '', 'Offline', '1', 1, 'avatar_female.png'),
(6, 'abi', 'sother', 'Abii', '1664188878', 'sother@gmail.com', '202cb962ac59075b964b07152d234b70', 0, '1664190798', 'Online', '1', 0, 'avatar_female.png'),
(7, 'tsamy', 'mutoni', 'phina', '1664189188', 'tsamy@gmail.com', '202cb962ac59075b964b07152d234b70', 0, '1664189212', 'Offline', '4', 0, 'avatar_female.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `citizens`
--
ALTER TABLE `citizens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `citizens`
--
ALTER TABLE `citizens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
